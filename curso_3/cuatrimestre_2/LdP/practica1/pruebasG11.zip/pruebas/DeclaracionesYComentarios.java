package es.uva.inf.lpd;
import java.util.*; //importamos todo java util
/*
 * Código para hacer pruebas con comentarios de nuestró programa de conteo
 * de línea de código
 * la línea de debajo dejada en blanco deliberadamente

 * @author juan
 */
public class DeclaracionesYComentarios {
    public static void main(String[] args) {

	int comentarioSimple = 5; // comentario simple
	int comentarioSimpleConTabuladorAlFinal = 5; // comentario simple	
	int comentarioMonolínea = 5; /* comentario monolínea */
	int comentarioMonolíneaConTabuladorAlFinal = 5; /* comentario monolínea */	

	int comentarioDobleMonolínea = 5; /* comentario monolínea *//* comentario monolínea */
	int comentarioDobleMonolíneaConTabuladorAlFinal = 5; /* comentario monolínea */		/* comentario monolínea */		

	int comentarioMultilinealínea = 5; /* comentario multi
	línea */
	int comentarioMultilinealínea1 = 5; /* comentario multi
	línea */ int lineaQueNoEsSoloComentario =5;
	int comentarioMultilinealínea2 = 5; /* comentario multi
	línea */ int lineaQueNoEsSoloComentarioConComentarioSimpleAlFinal =5; //Comentario Simple
	int comentarioMultilinealínea3 = 5; /* comentario multi
	línea */ int lineaQueNoEsSoloComentarioConComentarioMonoLíneaAlFinal =5; /* comentario monolínea */
	int comentarioMultilinealínea4 = 5; /* comentario multi
	línea */ int lineaQueNoEsSoloComentarioConComentarioMultiLíneaAlFinal =5; /* comentario multi
	línea */

	/* comentario antes */ int comentarioAntes = 5;
	/*comentario multi
	linea antes */ int comentarioMultiLineaAntes = 5;

	/* comentario antes */ int comentarioAntesYDespuesSimple = 5; // Y despues
	/* comentario antes */ int comentarioAntesYDespuesMonoLinea = 5; /* Y despues */

	int /* comentario entre medias */ comentarioEntreMedias /* comentario entre medias */ = /* comentario entre medias */ 5;
	int /* comentario entre 
	medias */ comentarioEntreMediasMultiLinea /* comentario entre 

	medias */ = /* comentario entre 


	medias */ 5 /* comentario entre 



	medias */;
    }
}
