public class PuntosYComas {
    public static void main(String[] args) {
	int lineaNormal = 5;
	int unEspacio = 5 ;
	int unTabulador = 5	;
	int unSaltoDeLinea = 5
	;
	int multiplesSaltoDeLinea = 5

	;
    }
}
