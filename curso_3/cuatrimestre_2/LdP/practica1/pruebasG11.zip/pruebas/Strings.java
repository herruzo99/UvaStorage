public class Strings {
	    public static void main(String[] args) {
		int i = 0; 
		String b = "Codigo "; if( i < 0){int a = 0;}; String c = "Otro string";
		String d = "String";
		String e = " if \" comilla dentro de string if " +
		// Comentario entre medias
		" continuar string en otra línea";
		int num = 0;
		String f = " if \" if comillas dentro \" if " +
		" continuar string en otra línea" +
		" varias lineas";

		char ch = '\"';
		char ch2 = '"';
		String prueba = " Hola que tal // /* if for while */ && || palabas reservadas dentro de string"; if( i < 0){int a = 0;};
		
	}
}
