let locationsInfo = [];
let contenedor = "images/iconos/amarillo.png";
const getLocations = () => {
    let locations = [{ lat: 41.638177, lng: -4.760635, text: "Calle Hernando de acuña, 22" }, { lat: 41.632450, lng: -4.749380, text: "Calle Hernando de acuña, 22" }, { lat: 41.647443, lng: -4.740972, text: "Calle Hernando de acuña, 22" }]
    locations.forEach(location => {
        let locationData = {
            position: { lat: location.lat, lng: location.lng },
            calle: location.text
        };
        locationsInfo.push(locationData)
    });
    initMap()
};



// Note: This example requires that you consent to location sharing when
// prompted by your browser. If you see the error "The Geolocation service
// failed.", it means you probably did not give permission for the browser to
// locate you.
var map;
function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 41.638177, lng: -4.760635 },
        zoom: 12
    });
    map.setOptions({
        styles: [
            {
                featureType: 'poi.business',
                stylers: [{ visibility: 'off' }]
            },
            {
                featureType: 'transit',
                elementType: 'labels.icon',
                stylers: [{ visibility: 'off' }]
            }
        ]
    });

    // Try HTML5 geolocation.
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            map.setCenter(pos);
        });
    }

    locationsInfo.map((place) => {

        var infowindow = new google.maps.InfoWindow({
            content: "<h6>" + place.calle + "</h6>"
        });


        var marker = new google.maps.Marker({
            position: place.position,
            map: map,
            icon: contenedor
        });
        marker.addListener('click', function () {
            infowindow.open(map, marker);
        });
        return marker
    })
}


window.addEventListener('load', getLocations);
