package rerego.model;

/**
 *
 * @author rebeca
 */
public class Post {

	private String titulo;
        private Integer id;
	private String nombreUsuario;
	private String texto;
	private String descripcion;
	private Integer visualizaciones;
	private Integer replicas;
	private Integer valoraciones;
	private String fechaCreacion;

	public Post() {
		nombreUsuario = "";
		titulo = "";
		texto = "";
		descripcion = "";
		visualizaciones = 0;
		valoraciones = 0;
		fechaCreacion = "2020-04-04";
		replicas = 0;
	}

	public Post(String nombreUsuario, String titulo, String texto, String descripcion) {
		this.nombreUsuario = nombreUsuario;
		this.titulo = titulo;
		this.texto = texto;
		this.descripcion = descripcion;
		visualizaciones = 0;
		valoraciones = 0;
		replicas = 0;
		fechaCreacion = "2020-04-04";
	}

	/**
	 * Devuelve la descripción de la publicación
	 *
	 * @return descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * Introduce la descripción de la publicación.
	 *
	 * @param descripcion
	 */
	public void getDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * Devuelve la fecha en la que se creó la publicación.
	 *
	 * @return fechaCreacion
	 */
	public String getFechaCreacion() {
		return fechaCreacion;
	}

	/**
	 * Devuelve el nombre del Usuario que ha creado la publicacion
	 *
	 * @return nombreUsuario
	 */
	public String getNombreUsario() {
		return nombreUsuario;
	}

	/**
	 * Deuvelve el número de replicas de la publicaicón
	 *
	 * @return valoraciones
	 */
	public String getReplica() {
		return replicas.toString();
	}

	/**
	 * Devuelve el texto de la pubicación
	 *
	 * @return texto
	 */
	public String getTexto() {
		return texto;
	}

	/**
	 * Devuelve el título de la publicación
	 *
	 * @return titulo
	 */
	public String getTitulo() {
		return titulo;
	}

	/**
	 * Deuvelve el número de valoraciones de la publicación
	 *
	 * @return valoraciones
	 */
	public String getValoraciones() {
		return valoraciones.toString();
	}

	/**
	 * Develve el número de visualizaciones de la publicación
	 *
	 * @return visualizaciones
	 */
	public String getVisualizaciones() {
		return visualizaciones.toString();
	}

	/**
	 * Quita 1 replica al total de valoraciones de la publicación.
	 */
	public void removeReplica() {
		replicas--;
	}

	/**
	 * Quita 1 valoración al total de valoraciones de la publicación.
	 */
	public void removeValoracion() {
		valoraciones--;
	}

	/**
	 * Introduce la fecha en la que se creó la publicación.
	 *
	 * @param fechaCreacion "YYY-MM-DD"
	 * @throws java.text.ParseException
	 */
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	/**
	 * Introduce un nombre de usuario
	 *
	 * @param nombreUsuario
	 */
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	
        
        /**
         * Introduce la cantidad de replicas de la publicacion
         * @param replica s
         */
        public void setReplicas(int replicas) {
		this.replicas= replicas;
	}
        
        /**
         * Introduce la cantidad de visualizaciones de la publicacion
         * @param visualizaciones  
         */
        public void setVisualizaciones(int visualizaciones) {
		this.visualizaciones= visualizaciones;
	}
        
        /**
         * Introduce la cantidad de valoraciones de la publicacion
         * @param valoraciones  
         */
        public void setValoraciones(int valoraciones) {
		this.valoraciones= valoraciones;
	}
        
        /**
         * Introduce la cantidad de valoraciones de la publicacion
         * @param valoraciones  
         */
        public void setId(int id) {
		this.id= id;
	}
	/**
	 * Introduce el texto de la pubicación
	 *
	 * @param texto
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}

	/**
	 * Introduce el título de la publicación
	 *
	 * @param titulo
	 */
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
        
        /**
	 * Añade una replica más a la publicación.
	 *
	 */
	public void addReplica() {
		replicas++;
	}
	/**
	 * Añade una valoración más a la publicación.
	 *
	 */
	public void addValoracion() {
		valoraciones++;
	}

	/**
	 * Añade una visualización más a la publicación
	 */
	public void addVisualizaciones() {
		visualizaciones++;
	}
}
