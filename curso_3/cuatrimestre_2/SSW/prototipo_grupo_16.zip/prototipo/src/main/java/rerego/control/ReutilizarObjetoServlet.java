/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import rerego.model.Categoria;
import rerego.model.Objeto;
import rerego.model.Post;
import rerego.model.PuntoGPS;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
@WebServlet(name = "ReutilizarObjetoServlet", urlPatterns = {"/ReutilizarObjeto"})
public class ReutilizarObjetoServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
                Usuario u = new Usuario("herruzo99", "pass", "juan herruzo", "Juan@df.c", "/prototipo_grupo16/images/perfil.png", "hoy",
				"tonto mucho");
		PuntoGPS p1 = new PuntoGPS(12.0, 12.0, "mia", "ayer");
		PuntoGPS p2 = new PuntoGPS(12.1, 12.1, "tuya", "ayer mucho");
		ArrayList<PuntoGPS> array = new ArrayList();
		array.add(p1);
		array.add(p2);
		Categoria c = new Categoria("Inorgánico", "Los envases y demás...", "./images/iconos/reciclaje.png",
				"#ff0", array);
		ArrayList<String> nombres = new ArrayList();
		nombres.add("un nombre");
		nombres.add("otro nombre");
		ArrayList<String> datos = new ArrayList();
		datos.add("Es una lata de metal");

		Objeto o = new Objeto("Lata de metal", u, "asi es como se recicla", "esto es la descripcion",
				"./images/lata.png", "2020-04-04", c, nombres, datos);
                
		Post publicacion1 = new Post(u.getNombre(), "Forma de reciclar en 5 segundos", "En nada veras como poder hacerlo",
				"Entra!");
		Post publicacion2 = new Post(u.getNombre(), "Truco interesante", "Como reciclar latas muy facilmente",
				"Ven y descubrelo");
		ArrayList<Post> publicaciones = new ArrayList<>();
		publicaciones.add(publicacion1);
		publicaciones.add(publicacion2);

		request.setAttribute("publicaciones", publicaciones);
		request.setAttribute("objeto", o);
		request.setAttribute("usuario_creado", u);
		request.setAttribute("categoria", c);
		RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/reutilizar.jsp");
		dispatcher.forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
