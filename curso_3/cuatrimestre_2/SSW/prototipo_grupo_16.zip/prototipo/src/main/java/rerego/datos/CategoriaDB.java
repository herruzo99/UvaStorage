/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.datos;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import rerego.model.Categoria;
import rerego.model.PuntoGPS;

/**
 *
 * @author pablojp
 */
public class CategoriaDB {
        /**
     * Para sacar usuarios de la base de datos.
     * 
     * @param login
     * @return 
     */
    public static Categoria selectCategoria(String nombre) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String selectCategoria = "SELECT * FROM CATEGORIA WHERE nombre = ?";
        String selectPuntoGPS = "SELECT * FROM PUNTOGPS WHERE categoria = ?";

        try {
            ps = connection.prepareStatement(selectCategoria);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            Categoria categoria = new Categoria();
            if (rs.next()) {
                categoria.setNombre(rs.getString("nombre"));
                categoria.setFoto(rs.getString("nombre"));
                categoria.setColor(rs.getString("color"));
                categoria.setDescripcion(rs.getString("descripcion"));
                
            }
            rs.close();
            ps.close();
            
            ps = connection.prepareStatement(selectPuntoGPS);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            ArrayList<PuntoGPS> puntosGPS = new ArrayList();
            if (rs.next()) {
               PuntoGPS punto = new PuntoGPS();
               punto.setLongitud(rs.getDouble("longitud"));
               punto.setLatitud(rs.getDouble("latitud"));
               punto.setFechaCreacion(rs.getDate("fechaCreacion").toString());
               punto.setCalle(rs.getString("calle"));
               puntosGPS.add(punto);
            }
            categoria.setPuntosGPS(puntosGPS);
            rs.close();
            ps.close();
            
            pool.freeConnection(connection);
            return categoria;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
       /**
     * Para sacar usuarios de la base de datos.
     * 
     * @param login
     * @return 
     */
    public static int updatePuntosCategoria(Categoria categoria) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "INSERT INTO PUNTOGPS (longitud, latitud, calle, fechaCreacion) VALUES (?, ?, ?, ?)";

        try {
            for(PuntoGPS punto : categoria.getPuntosGPS()){
                ps = connection.prepareStatement(query);
            ps.setDouble(1, punto.getLongitud());
            ps.setDouble(2, punto.getLatitud());
            ps.setString(3, punto.getCalle());
            ps.setDate(4, Date.valueOf(punto.getFechaCreacion()));
            ps.setString(4, categoria.getNombre());
            ps.executeUpdate();
            ps.close();

            }
            return 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
}
