package rerego.datos;

import java.sql.*;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
public class UsuarioDB {

    /**
     * Para insertar Usuarios en la base de datos.
     * 
     * @param usuario
     * @return 
     */
    public static int insert(Usuario usuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "INSERT INTO USUARIO (login, pass, nombre, email, fechaCreacion, descripcion, foto) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getPass());
            ps.setString(3, usuario.getNombre());
            ps.setString(4, usuario.getEmail());
            ps.setString(5, usuario.getFechaCreacion());
            ps.setString(6, usuario.getDescripcion());
            ps.setString(7, usuario.getFoto());
            int res = ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * Para sacar usuarios de la base de datos.
     * 
     * @param login
     * @return 
     */
    public static Usuario selectUser(String login) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM USUARIO WHERE login = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, login);
            rs = ps.executeQuery();
            Usuario usuario = null;
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setLogin(rs.getString("login"));
                usuario.setPass(rs.getString("pass"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setEmail(rs.getString("email"));
                usuario.setFechaCreacion(rs.getString("fechaCreacion"));
                usuario.setDescripcion(rs.getString("descripcion"));
                usuario.setFoto(rs.getString("foto"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return usuario;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
