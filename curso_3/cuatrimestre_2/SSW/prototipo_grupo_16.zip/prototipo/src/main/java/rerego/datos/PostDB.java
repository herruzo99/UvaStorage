/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.datos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import rerego.model.Post;
import rerego.model.Usuario;


/**
 *
 * @author Pablo
 */
public class PostDB {
    
    /**
     * Para sacar publicaciones de la base de datos
     * 
     * @param post
     * @return 
     */
    public static int insert(Post post) {

    ConnectionPool pool = ConnectionPool.getInstance();
    Connection connection = pool.getConnection();
     
    PreparedStatement ps = null;

    String query = "INSERT INTO USUARIO (titulo, nombreUsuario, texto, descripcion,visualizaciones, replica, valoraciones, fechaCreacion) VALUES (?, ?, ?, ?, ?, ?, ?)";
       try {
            ps = connection.prepareStatement(query);
            ps.setString(1, post.getTitulo());
            ps.setString(2, post.getNombreUsario());
            ps.setString(3, post.getTexto());
            ps.setString(4, post.getDescripcion());
            ps.setString(5, post.getVisualizaciones());
            ps.setString(6, post.getReplica());
            ps.setString(7, post.getValoraciones()); 
            ps.setString(8, post.getFechaCreacion());
            int res = ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    
    }
    
    public static Post selectPost(String id) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM PUBLICACION WHERE id = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            Post post = null;
            if (rs.next()) {
                post = new Post();
                post.setFechaCreacion(rs.getString("fechaCreacion"));
                post.setTitulo(rs.getString("titulo"));
                post.setTexto(rs.getString("texto"));
                post.setNombreUsuario(rs.getString("nombreUsuario"));
                post.setVisualizaciones(rs.getInt("visualizaciones"));
                post.setReplicas(rs.getInt("visualizaciones"));
                post.setValoraciones(rs.getInt("valoraciones"));
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        post.setId(generatedKeys.getInt(1));
                    }else {
                        throw new SQLException("Creating user failed, no ID obtained.");
                    }
                }
                
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return post;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}
