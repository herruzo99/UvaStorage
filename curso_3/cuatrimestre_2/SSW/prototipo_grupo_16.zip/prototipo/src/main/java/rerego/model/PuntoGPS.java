package rerego.model;

import java.io.Serializable;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class PuntoGPS implements Serializable {

	private Double longitud;
	private Double latitud;
	private String calle;
	private String fechaCreacion;

	public PuntoGPS() {
		longitud = 0.0;
		latitud = 0.0;
		fechaCreacion = "";
		calle = "";
	}

	public PuntoGPS(Double longitud, Double latitud, String calle, String fechaCreacion) {
		this.longitud = longitud;
		this.latitud = latitud;
		this.fechaCreacion = fechaCreacion;
		this.calle = calle;
	}

	/**
	 * @return the calle
	 */
	public String getCalle() {
		return calle;
	}

	/**
	 * @return the fechaCreacion
	 */
	public String getFechaCreacion() {
		return fechaCreacion;
	}

	/**
	 * @return the latitud
	 */
	public Double getLatitud() {
		return latitud;
	}

	/**
	 * @return the longitud
	 */
	public Double getLongitud() {
		return longitud;
	}

	/**
	 * @param calle the calle to set
	 */
	public void setCalle(String calle) {
		this.calle = calle;
	}

	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	/**
	 * @param latitud the latitud to set
	 */
	public void setLatitud(Double latitud) {
		this.latitud = latitud;
	}

	/**
	 * @param longitud the longitud to set
	 */
	public void setLongitud(Double longitud) {
		this.longitud = longitud;
	}

	@Override
	public String toString() {
		String datos = "";
		datos += latitud + "|";
		datos += longitud + "|";
		datos += calle;

		return datos;
	}
}
