GRANT FILE ON ReReGo_DB.* TO 'root'@'localhost' IDENTIFIED BY 'password';

DROP TABLE USUARIO;
DROP TABLE OBJETO;
DROP TABLE INFOOBJETO;
DROP TABLE OTROSNOMBRES;
DROP TABLE DATOSINTERESANTES;
DROP TABLE CATEGORIA;
DROP TABLE PUNTOGPS;
DROP TABLE PUBLICACION;

create table USUARIO
(
	login VARCHAR(20) not null unique,
	pass VARCHAR(20) not null,
	nombre VARCHAR(20) not null,
	email VARCHAR(50) not null,
	fechaCreacion DATE not null,
	descripcion VARCHAR(256),
	foto MEDIUMBLOB,
		PRIMARY KEY(login)
);

create table CATEGORIA
	(
		nombre VARCHAR(20) not null,
		foto MEDIUMBLOB,
                color VARCHAR(20),
		descripcion VARCHAR(256),
			PRIMARY KEY (nombre)
	);

create table OBJETO
(
	nombre VARCHAR(20) not null unique,
	foto MEDIUMBLOB,
		PRIMARY KEY(nombre)
);

create table INFOOBJETO
(
	id INT AUTO_INCREMENT,
	nombreObjeto VARCHAR(20) not null,
	loginUsuario VARCHAR(20) not null,
	como VARCHAR(180),
	descripcion VARCHAR(256),
	fechaCreacion DATE not null,
	categoria VARCHAR(20),
		PRIMARY KEY (id),
		FOREIGN KEY (nombreObjeto) REFERENCES OBJETO(nombre),
		FOREIGN KEY (categoria) REFERENCES CATEGORIA(nombre)
);

create table OTROSNOMBRES
	(
		id INT not null,
		otroNombre VARCHAR(20),
		FOREIGN KEY (id) REFERENCES INFOOBJETO(id)

	);

create table DATOSINTERESANTES
	(
		id INT not null,
		dato VARCHAR(240),
		FOREIGN KEY (id) REFERENCES INFOOBJETO(id)

	);


create table PUNTOGPS
	(
		id INT AUTO_INCREMENT,
		longitud DOUBLE(9,3),
		latitud DOUBLE(9,3),
                calle VARCHAR(30),
		fechaCreacion DATE not null,
		categoria VARCHAR(20),
			PRIMARY KEY(id),
			FOREIGN KEY (categoria) REFERENCES CATEGORIA(nombre)
	);

create table PUBLICACION
	(
		id INT AUTO_INCREMENT,
		fotoPerfil MEDIUMBLOB,
		fotoTexto MEDIUMBLOB,
		nombreUsuario VARCHAR(20),
		titulo VARCHAR(80) not null,
		texto VARCHAR(2000) not null,
		visualizaciones INT,
		valoraciones INT,
		fechaCreacion DATE not null,
			PRIMARY KEY(id),
			FOREIGN KEY(nombreUsuario) REFERENCES USUARIO(login)
	);


INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion)
VALUES ('hecgon','pass1','Héctor González', 'hectorgonzalez@gmail.com','2020-03-03');


INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion)
VALUES ('oscarg','pass2','Oscar Gómez', 'oscargomez@gmail.com','2019-11-03');


INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion, descripcion)
VALUES ('luis3','3pass','Luisito', 'luis.rodriguez@alumnos.uva.es','2019-10-02', 'Hola soy Luis y quiero todo lo que sepueda sobre reciclaje y reutilización.');

INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion)
VALUES ('beap','3pass4','Bea Pardo', 'beapardo@gmailcom','2019-10-02');


INSERT INTO OBJETO(nombre, foto)
VALUES ('lata', LOAD_FILE('./images/lata.png'));

INSERT INTO OBJETO(nombre)
VALUES ('bolígrafo');

INSERT INTO OBJETO(nombre)
VALUES ('cascara de naranja');

INSERT INTO OBJETO(nombre)
VALUES ('cartón');

INSERT INTO OBJETO(nombre)
VALUES ('televisor');

INSERT INTO CATEGORIA	( nombre,	descripcion)
VALUES ('orgánico', 'En esta categoría se destinan todos los objetos orgánicos, es decir, objetos con compuestos orgánicos que provienen de los restos de organismos que alguna vez estuvieron vivos, tales como plantas, animales...');

INSERT INTO CATEGORIA	( nombre,	descripcion)
VALUES ('inorgánico', 'En esta categoría se inclullen los objetos hecho con materiales que no está hechos de carbono y no son fabricados por los seres vivos, sino por reacciones químicas.');

INSERT INTO CATEGORIA	( nombre,	descripcion)
VALUES ('punto limpio', 'Al punto limpio se destinan los objetos de composición de estos residuos, que puede llegar a ser tóxica y que es esencial separar de los de otro tipo.');

INSERT INTO CATEGORIA	( nombre, descripcion)
VALUES ('papel y cartón', 'En esta categoría todos los objetos hechos de papel y cartón.');

INSERT INTO INFOOBJETO( nombreObjeto,loginUsuario, como, descripcion, fechaCreacion,categoria)
VALUES('lata', 'admin', 'Contedor amarillo', 'Las latas se reciclan vacías en	el contenedor amarillo. Este contenedor está destinado al reciclaje de embases.', '2019-02-02', 'inorgánico');


INSERT INTO INFOOBJETO( nombreObjeto,loginUsuario, como, descripcion, fechaCreacion,categoria)
VALUES('bolígrafo','admin', 'Punto limpio', 'Una vez gastda la tinta del bolígrafo se puede reciclar en el los puntos limpios,', '2019-02-02','punto limpio' );

INSERT INTO INFOOBJETO( nombreObjeto, loginUsuario, como,  fechaCreacion, categoria)
VALUES('cascara de naranja','luis3', 'contenedor orgánico', '2020-02-12', 'orgánico' );

INSERT INTO INFOOBJETO( nombreObjeto,loginUsuario, como, descripcion, fechaCreacion, categoria)
VALUES('cartón','oscarg', 'Contenedor azul', 'El cartón ha de ir al contenedor azul,	es el mismo que el de papel','2020-04-12','papel y cartón' );

INSERT INTO INFOOBJETO( nombreObjeto,loginUsuario, como, descripcion, fechaCreacion, categoria)
VALUES('televisor','beap', 'Punto limpio', 'Puedes llevarlo al punto limpio de	tu ciudad o puedo o llamar para que te lo recojan en casa.','2020-04-12', 'punto limpio' );

INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('5', 'tele');

INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('4', 'cartulina');

INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('3', 'fruta');

INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('3', 'cascara');

INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('3', 'piel de fruta');

INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('3', 'comida');

INSERT INTO DATOSINTERESANTES	(id,	dato )
VALUES ('2', 'Los bolígrafos más sostenibles y que menos perjudican almedio ambiente son los recargables');

INSERT INTO PUNTOGPS ( longitud, latitud,	fechaCreacion, categoria)
VALUES('-4.7237200', '41.6551800', '2020-02-12','orgánico');

INSERT INTO PUNTOGPS ( longitud, latitud,	fechaCreacion,categoria	)
VALUES('-4.7503400', '441.6547100', '2020-02-02','inorgánico');

INSERT INTO PUNTOGPS ( longitud, latitud,	fechaCreacion,categoria	)
VALUES('41.65227127', '-4.72850275', '2020-01-02','punto limpio');

INSERT INTO PUNTOGPS ( longitud, latitud,	fechaCreacion,categoria	)
VALUES('-4.7257100', '41.6424200', '2020-01-02','inorgánico');

INSERT INTO PUNTOGPS ( longitud, latitud,	fechaCreacion,categoria	)
VALUES('41.645556', '-4.7325', '2020-01-02','orgánico');

INSERT INTO PUBLICACION	(nombreUsuario,	titulo,	texto, fechaCreacion)
VALUES('hecgon', 'Luces y macetas de jardín con latas.','Una forma muy original de reaprovechar latas es convertirlas en lámparas de exterior que ofrecen una
              luz íntima y perfecta para las veladas más relajadas. Para ello, tan solo tendrás que buscar las
              latas de conserva que pueden ser de todos los tamaños, límpialas con abundante agua y jabón y
              sécalas.
							Después, tendrás que meterlas en el congelador para poder
              darle el diseño
              que buscas y hacerle los agujeros fácilmente. Antes de meterla dentro del congelador tendrás que
              rellenar 3/4 de lata para evitar que se deforme con el frío, déjala una hora, aproximadamente, hasta
              que el agua esté completamente congelada.
							A continuación tan solo tienes que perforarla con unos clavos siguiendo el
              diseño que prefieras: un sol, un espiral, la luna, etcétera. Tendrás que clavar los clavos siguiendo
              el dibujo que buscas y después sacarlos con cuidado para que no se rompa. Una vez listo, puedes
              darle una capa de pintura y decorar a tu gusto tu lámpara hecha con latas. Introduce una vela en su
              interior ¡y listo!', '2020-04-04');

INSERT INTO PUBLICACION	(nombreUsuario,	titulo,	texto, fechaCreacion)
VALUES('beap', 'Rallador y Organizador de escritorio con latas','Si acabas de mudarte y no tienes un rallador para preparar tu ensalada favorita, o agregar queso a tus pastas, puedes improvisar uno con una lata de conservas, levemente hundida hacia adentro y con orificios a intervalos regulares. Asegúrate de que esté bien limpia y de limar bien los agujeros para que nada del aluminio pase a tus comidas.
	Si tomas algunas latas de conservas, las limpias bien y las envuelves con un papel de un estampado bonito, puedes crear un organizador de escritorio práctico y original, donde colocar tus lápices y otros útiles. Solo debes apilar las latas juntas y unirlas con ayuda de una pistola encoladora.', '2020-04-04');

INSERT INTO PUBLICACION	(nombreUsuario,	titulo,	texto, fechaCreacion)
VALUES('beap', '10 maneras originales de reciclar ropa','1. Los jerséis te abrigan en invierno pero llega un momento que se llenan de bolitas y se desgastan por algunas zonas. Con un poco de aguja e hilo, puedes convertir ese jersey en unos calentitos guantes para el invierno aprovechando el tejido.
2. Si tienes una mascota, seguro que habrás pensado en comprarle una camita, pero ¿por qué no hacerla tú mismo? Con un jersey viejo y un poco de algodón de relleno, puedes hacer una cómoda cama para tu gato o perro.
3. Ya que hablamos de jerséis, si con la tela hemos fabricado unos guantes, con las mangas podemos hacer unos calentadores a juego, para llevar con botas de caña alta y no pasar frío en los meses más duros del invierno.
4. Si tienes varias camisetas de algodón que te aburren pero lo tuyo no es coser precisamente, puedes crear diversos patrones originales con paciencia y un par de tijeras, para lucir unas bonitas camisetas en verano.
5. Para los más pequeños también hay ideas. ¿Por qué no convertir los calcetines viejos o las camisetas en adorables peluches?
6. De las camisetas de algodón de colores podemos conseguir el famoso trapillo, con el que realizar verdaderas obras de arte mediante su trenzado.
7. Con un poco de cinta de carrocero y pintura para ropa, animarás esos aburridos zapatos que ya no te ponías.
8. Una corbata también puede convertirse en algo nuevo y útil, como por ejemplo, una funda de móvil.
9. Con unas flores y un poco de encaje, tus pantalones vaqueros o camisetas quedarán a la par de las nuevas tendencias.
10. Unos pantalones vaqueros pueden tener su segunda oportunidad en forma de mochila para el colegio o para excursiones, con todos los bolsillos que quieras.', '2020-04-04');

INSERT INTO PUBLICACION	(nombreUsuario,	titulo,	texto, fechaCreacion)
VALUES('beap', '5 útiles consejos para reutilizar botellas de plástico','1. Macetas para cultivar tomates
Una perfecta solución para personas que quieren disfrutar de tomates de cosecha propia, pero no tienen un patio. Podemos cultivar nuestros propios alimentos incluso disponiendo de muy pocos metros utilizando botellas de plástico.
2. Coche solar casero de juguete
Una manualidad ideal para hacer con los más pequeños de la casa. Además la mayoría de los materiales que usaremos serán reciclados.
3. Linterna casera
La base del proyecto será una botella de plástico que, junto con palitos de helado, pegamento y el material eléctrico necesario, nos harán pasar un buen rato y poder fabricar nuestra propia linterna casera.
4. Árbol de Navidad
Con botellas PET de color verde, de las que hay muchas en el mercado, podemos hacer un árbol de navidad visualmente muy atractivo.
5. Goteo solar con botellas de plástico
Kondenskompressor es una técnica que produce agua destilada con radiación solar. Es un sistema muy simple y eficaz que produce un ͞goteo solar͟ mediante el cual se puede reducir el agua de riego 10 veces respecto a sistemas tradicionales.', '2020-04-04');