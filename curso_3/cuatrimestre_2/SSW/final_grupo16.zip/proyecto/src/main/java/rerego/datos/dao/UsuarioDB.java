package rerego.datos.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import rerego.datos.ConnectionPool;
import rerego.model.Usuario;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class UsuarioDB {

    /**
     * Para insertar Usuarios en la base de datos.
     *
     * @param usuario
     * @return
     */
    public static int insert(Usuario usuario) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "INSERT INTO USUARIO (login, pass, nombre, email, fechaCreacion, descripcion, foto) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, usuario.getLogin());
            ps.setString(2, usuario.getPass());
            ps.setString(3, usuario.getNombre());
            ps.setString(4, usuario.getEmail());
            ps.setString(5, usuario.getFechaCreacion());
            ps.setString(6, usuario.getDescripcion());
            if (usuario.getFoto().getSubmittedFileName().isEmpty()) {
                ps.setBlob(7, (InputStream) getFoto("admin").getBinaryStream());
            } else {
                ps.setBlob(7, usuario.getFoto().getInputStream());
            }
            int res = ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } catch (IOException ex) {
            Logger.getLogger(UsuarioDB.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }

    private static Blob getFoto(String login) {
        try {
            ConnectionPool pool = ConnectionPool.getInstance();
            Connection connection = pool.getConnection();
            PreparedStatement ps = null;
            ResultSet rs = null;
            String selectObjeto = "SELECT foto FROM USUARIO WHERE login = ?";
            ps = connection.prepareStatement(selectObjeto);
            ps.setString(1, login);
            rs = ps.executeQuery();

            if (rs.next()) {
                Blob blob = rs.getBlob("foto");
                if (!rs.wasNull() && blob.length() > 1) {
                    return blob;
                }

            }
        } catch (SQLException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    /**
     * Para sacar usuarios de la base de datos.
     *
     * @param login
     * @return
     */
    public static Usuario selectUser(String login) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM USUARIO WHERE login = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, login);
            rs = ps.executeQuery();
            Usuario usuario = null;
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setLogin(rs.getString("login"));
                usuario.setPass(rs.getString("pass"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setEmail(rs.getString("email"));
                usuario.setFechaCreacion(rs.getString("fechaCreacion"));
                usuario.setDescripcion(rs.getString("descripcion"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return usuario;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     *
     *
     * @param login pk de USUARIO
     * @param foto aqui queda guardad la foto del objeto
     */
    public static void getFoto(String login, OutputStream foto) {
        try {
            ConnectionPool pool = ConnectionPool.getInstance();
            Connection connection = pool.getConnection();
            PreparedStatement ps = null;
            ResultSet rs = null;
            String selectObjeto = "SELECT foto FROM USUARIO WHERE login = ?";
            ps = connection.prepareStatement(selectObjeto);
            ps.setString(1, login);
            rs = ps.executeQuery();

            if (rs.next()) {
                Blob blob = rs.getBlob("foto");
                if (!rs.wasNull() && blob.length() > 1) {
                    InputStream imagen = blob.getBinaryStream();
                    byte[] buffer = new byte[1000];
                    int len = imagen.read(buffer);
                    while (len != -1) {
                        foto.write(buffer, 0, len);
                        len = imagen.read(buffer);
                    }
                    imagen.close();
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *
     * @param login
     * @return devuelve el número de filas afectadas
     */
    public static int removeUser(String login) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        PreparedStatement psR = null;
        String queryR = "DELETE FROM USUARIO WHERE login = ?";
        String query = "UPDATE INFOOBJETO SET loginUsuario = 'ghost' WHERE loginUsuario = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, login);
            ps.executeUpdate();

            psR = connection.prepareStatement(queryR);
            psR.setString(1, login);
            int rs = psR.executeUpdate();

            psR.close();
            pool.freeConnection(connection);
            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     *
     * @param email
     * @return
     */
    public static Usuario selectUserByEmail(String email) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM USUARIO WHERE email = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, email);
            rs = ps.executeQuery();
            Usuario usuario = null;
            if (rs.next()) {
                usuario = new Usuario();
                usuario.setLogin(rs.getString("login"));
                usuario.setPass(rs.getString("pass"));
                usuario.setNombre(rs.getString("nombre"));
                usuario.setEmail(rs.getString("email"));
                usuario.setFechaCreacion(rs.getString("fechaCreacion"));
                usuario.setDescripcion(rs.getString("descripcion"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return usuario;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     *
     * @param user
     * @param oldLogin
     * @return el numero de filas afectadas
     */
    public static int updateInfo(Usuario user, String oldLogin) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String addInfo = "UPDATE USUARIO SET login =?, nombre = ?, email = ?, descripcion = ?  WHERE login = ?";

        try {
            ps = connection.prepareStatement(addInfo, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getLogin());
            ps.setString(2, user.getNombre());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getDescripcion());
            ps.setString(5, oldLogin);
            int rs = ps.executeUpdate();

            ps.close();

            pool.freeConnection(connection);
            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     *
     * @param user
     * @return el numero de filas afectadas
     */
    public static int updatePass(Usuario user) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String addInfo = "UPDATE USUARIO SET pass = ? WHERE login = ?";

        try {
            ps = connection.prepareStatement(addInfo, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, user.getPass());
            ps.setString(2, user.getLogin());
            int rs = ps.executeUpdate();

            ps.close();

            pool.freeConnection(connection);
            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     *
     * @param user
     * @return el numero de filas afectadas
     */
    public static int updateFoto(Usuario user) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String addInfo = "UPDATE USUARIO SET foto = ? WHERE login = ?";

        try {
            ps = connection.prepareStatement(addInfo, Statement.RETURN_GENERATED_KEYS);
            ps.setBlob(1, user.getFoto().getInputStream());
            ps.setString(2, user.getLogin());
            int rs = ps.executeUpdate();

            ps.close();

            pool.freeConnection(connection);
            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } catch (IOException ex) {
            Logger.getLogger(UsuarioDB.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
}
