/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control.users;

import rerego.control.users.utility.CookiesKitchen;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import rerego.datos.dao.UsuarioDB;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
@WebServlet(name = "IniciarSesionServlet", urlPatterns = {"/iniciarsesion"})
public class IniciarSesionServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario == null) {
            // Si no hay usuario mostramos iniciarsesion.jsp
            String url = "/user/iniciarsesion.jsp";
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
            dispatcher.forward(request, response);
        } else {
            // Si hay usuario redirigimos a perfil
            response.sendRedirect("/rerego/perfil");
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario != null) {
            // Si hay usuario redirigimos a perfil
            response.sendRedirect("/rerego/perfil");
        } else {
            request.setCharacterEncoding("UTF-8");
            // Si no hay usuario procedemos a iniciar sesión
            HttpSession session = request.getSession();
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String passwordHash = Usuario.getSecurePassword(password);
            password = null;
            String rememberusername = request.getParameter("rememberusername");
            Usuario user = UsuarioDB.selectUser(username);
            if (user == null || !user.getPass().equals(passwordHash)) {
                // Error al iniciar sesión
                String mensajeError = "El nombre de usuario no existe o la contraseña es incorrecta.<br/>";
                session.setAttribute("mensajeError", mensajeError);
                response.sendRedirect("/rerego/iniciarsesion");
            } else {
                // Guardamos el usuario en la sesión...
                session.setAttribute("LoggedUser", user);
                if (rememberusername != null && rememberusername.equals("on")) {
                    // ...y en cookies si decide mantener la sesión abierta
                    Cookie login = new Cookie("login", username);
                    Cookie hash = new Cookie("hash", passwordHash);
                    login.setMaxAge(60 * 60 * 24 * 365 * 2); // 2 años
                    hash.setMaxAge(60 * 60 * 24 * 365 * 2); // 2 años
                    login.setPath("/");
                    hash.setPath("/");
                    response.addCookie(login);
                    response.addCookie(hash);
                }
                // Redirigimos al perfil
                response.sendRedirect("/rerego/perfil");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
