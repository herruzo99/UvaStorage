/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control.users;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import rerego.control.users.utility.CookiesKitchen;
import rerego.datos.dao.UsuarioDB;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
@WebServlet(name = "CompletarPerfilServlet", urlPatterns = {"/completarperfil"})
@MultipartConfig
public class CompletarPerfilServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario != null) {
            // Si hay usuario redirigimos a perfil
            response.sendRedirect("/rerego/perfil");
        } else {
            request.setCharacterEncoding("UTF-8");
            // Si no hay usuario procedemos a finalizar el registro
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String passwordHash = request.getParameter("passwordHash");
            String name = request.getParameter("name");
            if (name == null || name.isEmpty()) {
                name = username;
            }
            String description = request.getParameter("description");
            Part photo = request.getPart("photo");
            boolean error = false;
            String mensajeError = "";
            if (name.length() < 4 || name.length() > 20) {
                // Nombre para mostrar no válido
                error = true;
                mensajeError += "El nombre tiene que tener entre 4 y 20 caracteres.<br/>";
            }
            if (description.length() > 256) {
                // Descripción no válida
                error = true;
                mensajeError += "La descripción es demasiado grande.<br/>";
            }
            if (photo.getSize() > 16777215) {
                // Imagen pesa más de 16MB
                error = true;
                mensajeError += "La foto de perfil es demasiado grande.<br/>";
            }
            HttpSession session = request.getSession();
            if (error == true) {
                session.setAttribute("mensajeError", mensajeError);
                request.setAttribute("username", username);
                request.setAttribute("email", email);
                request.setAttribute("passwordHash", passwordHash);
                String url = "/user/completarperfil.jsp";
                RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
                dispatcher.forward(request, response);
            } else {
                // Todo correcto, creamos el usuario y lo guardamos...
                long millis = System.currentTimeMillis();
                Date date = new Date(millis);
                Usuario user = new Usuario(username, passwordHash, name, email, photo, date.toString(), description);
                UsuarioDB.insert(user); // ...en la BD...
                session.setAttribute("LoggedUser", user); // ...y en la sesión.
                response.sendRedirect("/rerego/perfil");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
