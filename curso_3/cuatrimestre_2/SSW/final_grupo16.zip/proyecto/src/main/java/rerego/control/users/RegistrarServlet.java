/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control.users;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import rerego.control.users.utility.CookiesKitchen;
import rerego.datos.dao.UsuarioDB;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
@WebServlet(name = "RegistrarServlet", urlPatterns = {"/registrar"})
public class RegistrarServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario != null) {
            // Si hay usuario redirigimos a perfil
            response.sendRedirect("/rerego/perfil");
        } else {
            // Si no hay usuario mostramos registrar.jsp
            String url = "/user/registrar.jsp";
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
            dispatcher.forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario != null) {
            // Si hay usuario redirigimos a perfil
            response.sendRedirect("/rerego/perfil");
        } else {
            request.setCharacterEncoding("UTF-8");
            // Si no hay usuario procedemos con el registro
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            String repassword = request.getParameter("repassword");
            boolean error = false;
            String mensajeError = "";
            String passwordHash = Usuario.getSecurePassword(password);
            if (password.length() < 8 || password.length() > 20) {
                // Contraseña no válida
                error = true;
                mensajeError += "La contraseña tiene que tener entre 8 y 20 caracteres.<br/>";
            }
            if (!password.equals(repassword)) {
                // Las contraseñas no coinciden
                error = true;
                mensajeError += "Las contraseñas no coinciden.<br/>";
            }
            password = null;
            repassword = null;
            if (UsuarioDB.selectUser(username) != null) {
                // Ya existe este nombre de usuario
                error = true;
                mensajeError += "Este nombre de usuario ya esta ocupado.<br/>";
            }
            if (UsuarioDB.selectUserByEmail(email) != null) {
                // Ya existe ese correo
                error = true;
                mensajeError += "Este correo electrónico ya está en uso.<br/>";
            }
            if (username.length() < 4 || username.length() > 20) {
                // Nombre de usuario no válido
                error = true;
                mensajeError += "El nombre de usuario tiene que tener entre 4 y 20 caracteres.<br/>";

            }
            if (email.length() > 50) {
                // Email demasiado grande
                error = true;
                mensajeError += "Correo electrónico máximo 50 caracteres. Háztelo mirar, no es normal.<br/>";
            }
            if (error == true) {
                HttpSession session = request.getSession();
                session.setAttribute("mensajeError", mensajeError);
                response.sendRedirect("/rerego/registrar");
            } else {

                request.setAttribute("username", username);
                request.setAttribute("email", email);
                request.setAttribute("passwordHash", passwordHash);
                // Todavía no hemos terminado el registro...
                String url = "/user/completarperfil.jsp";
                RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
                dispatcher.forward(request, response);
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
