/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.datos.dao;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rerego.datos.ConnectionPool;
import rerego.model.Categoria;
import rerego.model.PuntoGPS;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class CategoriaDB {
    /**
     * Para sacar categorias de la base de datos.
     * 
     * @param login
     * @return 
     */
    public static Categoria selectCategoria(String nombre) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String selectCategoria = "SELECT * FROM CATEGORIA WHERE nombre = ?";
        String selectPuntoGPS = "SELECT * FROM PUNTOGPS WHERE categoria = ?";

        try {
            ps = connection.prepareStatement(selectCategoria);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            Categoria categoria = new Categoria();
            if (rs.next()) {
                categoria.setNombre(rs.getString("nombre"));
                categoria.setColor(rs.getString("color"));
                categoria.setDescripcion(rs.getString("descripcion"));
                
            }
            rs.close();
            ps.close();
            
            ps = connection.prepareStatement(selectPuntoGPS);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            ArrayList<PuntoGPS> puntosGPS = new ArrayList();
            while (rs.next()) {
               PuntoGPS punto = new PuntoGPS();
               punto.setLongitud(rs.getFloat("longitud"));
               punto.setLatitud(rs.getFloat("latitud"));
               punto.setFechaCreacion(rs.getDate("fechaCreacion").toString());
               puntosGPS.add(punto);
            }
            categoria.setPuntosGPS(puntosGPS);
            rs.close();
            ps.close();
            
            pool.freeConnection(connection);
            return categoria;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    public static List<Categoria> getCategorias() {
        
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        PreparedStatement psPto = null;
        ResultSet rsPto = null;
        String selectCategoria = "SELECT nombre, descripcion, color  FROM CATEGORIA";
        String selectPuntoGPS = "SELECT * FROM PUNTOGPS WHERE categoria = ?";
               
        try {
            ps = connection.prepareStatement(selectCategoria);
            rs = ps.executeQuery();
            ArrayList<Categoria> categorias = new ArrayList<>();
          
            while (rs.next()) {
                Categoria categoria = new Categoria();
                categoria.setNombre(rs.getString("nombre"));
                categoria.setColor(rs.getString("color"));
                categoria.setDescripcion(rs.getString("descripcion"));
             
                psPto = connection.prepareStatement(selectPuntoGPS);
                psPto.setString(1,rs.getString("nombre"));
                rsPto = psPto.executeQuery();
                ArrayList<PuntoGPS> puntosGPS = new ArrayList();
                while (rsPto.next()) {
                   PuntoGPS punto = new PuntoGPS();
                   punto.setLongitud(rsPto.getFloat("longitud"));
                   punto.setLatitud(rsPto.getFloat("latitud"));
                   punto.setFechaCreacion(rsPto.getDate("fechaCreacion").toString());
                   puntosGPS.add(punto);
                }
                categoria.setPuntosGPS(puntosGPS);
                categorias.add(categoria);
                rsPto.close();
                psPto.close();
             }
            
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            
            return categorias;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Para sacar usuarios de la base de datos.
     * 
     * @param login
     * @return 
     */
    public static int updatePuntosCategoria(Categoria categoria) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
         int rs = 0;
        String delete_query = "DELETE FROM PUNTOGPS WHERE categoria = ?";
        String query = "INSERT INTO PUNTOGPS (longitud, latitud, fechaCreacion, categoria) VALUES (?, ?, ?, ?)";

        try {
            ps = connection.prepareStatement(delete_query);
            ps.setString(1, categoria.getNombre());
            ps.executeUpdate();
            ps.close(); 

            for(PuntoGPS punto : categoria.getPuntosGPS()){
                ps = connection.prepareStatement(query);
                ps.setFloat(1, punto.getLongitud());
                ps.setFloat(2, punto.getLatitud());
                ps.setDate(3, Date.valueOf(punto.getFechaCreacion()));
                ps.setString(4, categoria.getNombre());
                rs += ps.executeUpdate();
                ps.close();
            }
            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * 
     * @param nombre
     * @param foto 
     */
     public static void getFoto (String nombre, OutputStream foto) {
        try{
             ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String selectObjeto = "SELECT foto FROM CATEGORIA WHERE nombre = ?";
        ps = connection.prepareStatement(selectObjeto);
        ps.setString(1, nombre);
        rs = ps.executeQuery();
        
        if(rs.next()){
            Blob blob = rs.getBlob("foto");
            if(!rs.wasNull() && blob.length() > 1){
                InputStream imagen = blob.getBinaryStream();
                byte[] buffer = new byte[1000];
                int len = imagen.read(buffer);
                while (len != -1){
                    foto.write(buffer,0, len);
                    len = imagen.read(buffer);
                }
                imagen.close();
            }

        }
        } catch (IOException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
     /**
      * 
      * @param nombre
      * @param icono 
      */
     public static void getIcono(String nombre, OutputStream icono) {
        try{
             ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String selectObjeto = "SELECT icono FROM CATEGORIA WHERE nombre = ?";
        ps = connection.prepareStatement(selectObjeto);
        ps.setString(1, nombre);
        rs = ps.executeQuery();
        
        if(rs.next()){
            Blob blob = rs.getBlob("icono");
            if(!rs.wasNull() && blob.length() > 1){
                InputStream imagen = blob.getBinaryStream();
                byte[] buffer = new byte[1000];
                int len = imagen.read(buffer);
                while (len != -1){
                    icono.write(buffer,0, len);
                    len = imagen.read(buffer);
                }
                imagen.close();
            }

        }
        } catch (IOException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
