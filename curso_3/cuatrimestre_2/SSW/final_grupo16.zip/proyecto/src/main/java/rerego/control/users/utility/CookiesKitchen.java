/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control.users.utility;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import rerego.datos.dao.UsuarioDB;
import rerego.model.Usuario;

/**
 * Helper para cosas relacionadas con cookies/sesiones.
 *
 * @author pablojp
 */
public class CookiesKitchen {

    /**
     * Obtiene las cookies de un request y las elimina en el response
     *
     * @param request
     * @param response
     */
    public static void CleanCookies(HttpServletRequest request, HttpServletResponse response) {
        Cookie[] cookies = request.getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie != null) {
                    cookie.setValue(null);
                    cookie.setPath("/");
                    cookie.setMaxAge(0);
                    response.addCookie(cookie);
                }
            }
        }
    }

    /**
     * Obtine las cookies del request en busca de login y hash, los comprueba y
     * devuelve el usuario correspondiente, o null.
     *
     * @param request
     * @param response
     * @return objeto Usuario correspondiente según las cookies, null si falla.
     */
    public static Usuario GetCookiesUser(HttpServletRequest request, HttpServletResponse response) {
        Cookie[] cookies = request.getCookies();
        String login = "";
        String hash = "";
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookie != null) {
                    if (cookie.getName().equals("login")) {
                        login = cookie.getValue();
                    } else if (cookie.getName().equals("hash")) {
                        hash = cookie.getValue();
                    }
                }
            }
        }
        Usuario usuario = UsuarioDB.selectUser(login);
        if (usuario == null || !usuario.getPass().equals(hash)) {
            // Si el login o el hash no son correctos eliminamos las cookies
            CookiesKitchen.CleanCookies(request, response);
        }
        return usuario;
    }

    /**
     * Obtener el objeto usuario que está iniciado sesión en el sistema, ya sea
     * mediante cookies o mediante sesión.
     *
     * @param request
     * @param response
     * @return
     */
    public static Usuario GetUser(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        Usuario usuario = (Usuario) session.getAttribute("LoggedUser");
        if (usuario == null) {
            // No hay sesión, obtenemos el usuario con las cookies
            usuario = CookiesKitchen.GetCookiesUser(request, response);
            if (usuario != null) {
                // Guardamos en la sesión para no tener que mirar cookies de nuevo
                session.setAttribute("LoggedUser", usuario);
            }
        }
        return usuario;
    }

}
