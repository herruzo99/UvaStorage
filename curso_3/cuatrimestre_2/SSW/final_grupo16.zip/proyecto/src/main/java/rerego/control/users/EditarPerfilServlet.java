/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control.users;

import rerego.control.users.utility.CookiesKitchen;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import rerego.datos.dao.PostDB;
import rerego.datos.dao.UsuarioDB;
import rerego.model.Post;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
@WebServlet(name = "EditarPerfilServlet", urlPatterns = {"/editarperfil"})
@MultipartConfig
public class EditarPerfilServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario == null) {
            // Si no hay usuario redirigimos a iniciarsesion
            response.sendRedirect("/rerego/iniciarsesion");
        } else {
            // Si hay usuario mostramos editarperfil.jsp

            request.setAttribute("usuario", usuario);

            String url = "/user/editarperfil.jsp";
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
            dispatcher.forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario == null) {
            // Si no hay usuario redirigimos a iniciarsesion
            response.sendRedirect("/rerego/perfil");
        } else {
            request.setCharacterEncoding("UTF-8");
            // Si hay usuario procedemos a actualizar
            String username = request.getParameter("username");
            String email = request.getParameter("email");
            String name = request.getParameter("name");
            if (name == null || name.isEmpty()) {
                name = username;
            }
            String description = request.getParameter("description");
            Part photo = request.getPart("photo");
            boolean error = false;
            String mensajeError = "";
            if (!usuario.getLogin().equals(username) && UsuarioDB.selectUser(username) != null) {
                // Ya existe este nombre de usuario
                error = true;
                mensajeError += "Este nombre de usuario ya esta ocupado.<br/>";
            }
            if (!usuario.getEmail().equals(email) && UsuarioDB.selectUserByEmail(email) != null) {
                // Ya existe ese correo
                error = true;
                mensajeError += "Este correo electrónico ya está en uso.<br/>";
            }
            if (username.length() < 4 || username.length() > 20) {
                // Nombre de usuario no válido
                error = true;
                mensajeError += "El nombre de usuario tiene que tener entre 4 y 20 caracteres.<br/>";

            }
            if (email.length() > 50) {
                // Email demasiado grande
                error = true;
                mensajeError += "Correo electrónico máximo 50 caracteres. Háztelo mirar, no es normal.<br/>";
            }
            if (name.length() < 4 || name.length() > 20) {
                // Nombre para mostrar no válido
                error = true;
                mensajeError += "El nombre tiene que tener entre 4 y 20 caracteres.<br/>";
            }
            if (description.length() > 256) {
                // Descripción no válida
                error = true;
                mensajeError += "La descripción es demasiado grande.<br/>";
            }
            if (photo.getSize() > 16777215) {
                // Imagen pesa más de 16MB
                error = true;
                mensajeError += "La foto de perfil es demasiado grande.<br/>";
            }
            if (error == true) {
                HttpSession session = request.getSession();
                session.setAttribute("mensajeError", mensajeError);
                response.sendRedirect("/rerego/editarperfil");
            } else {
                String oldLogin = usuario.getLogin();
                usuario.setLogin(username);
                usuario.setEmail(email);
                usuario.setNombre(name);
                usuario.setDescripcion(description);
                UsuarioDB.updateInfo(usuario, oldLogin);
                if (!photo.getSubmittedFileName().isEmpty()) {
                    usuario.setFoto(photo);
                    UsuarioDB.updateFoto(usuario);
                }
                response.sendRedirect("/rerego/perfil");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
