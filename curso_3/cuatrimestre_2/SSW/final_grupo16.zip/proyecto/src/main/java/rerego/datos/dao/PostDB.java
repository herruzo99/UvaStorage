/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.datos.dao;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rerego.datos.ConnectionPool;
import rerego.model.Objeto;
import rerego.model.Post;
import rerego.model.Usuario;

/**
 * Se comunica con las tablas de la BD ReReGo_DB correspondientes a las
 * publicaciones.
 *
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class PostDB {

    /**
     * Inserta una nueva publicación dada en la tabla PUBLICACION de la BD
     * ReReGo
     *
     * @param post publicacion que se quiere introducir en la BD
     * @return número de filas afectadas
     */
    public static int insert(Post post) {

        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "INSERT INTO PUBLICACION (titulo, nombreUsuario, texto, visualizaciones, valoraciones, fechaCreacion, descripcion) VALUES (?, ?, ?, ?, ?, ?,?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, post.getTitulo());
            ps.setString(2, post.getNombreUsario());
            ps.setString(3, post.getTexto());
            ps.setString(4, post.getVisualizaciones());
            ps.setString(5, post.getValoraciones());
            ps.setString(6, post.getFechaCreacion());
            ps.setString(7, post.getDescripcion());
            int res = ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     * Obtiene la publicación correspondiente a la id dada
     *
     * @param id de la publicación que se quiere sacar de la BD
     * @return Post
     */
    public static Post selectPost(String id) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM PUBLICACION WHERE id = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, id);
            rs = ps.executeQuery();
            Post post = null;
            if (rs.next()) {
                post = new Post();
                post.setFechaCreacion(rs.getString("fechaCreacion"));
                post.setTitulo(rs.getString("titulo"));
                post.setTexto(rs.getString("texto"));
                post.setNombreUsuario(rs.getString("nombreUsuario"));
               
                   post.setVisualizaciones(rs.getInt("visualizaciones"));
                
                post.setReplicas(rs.getInt("hechos"));
                post.setValoraciones(rs.getInt("valoraciones"));
                post.setId(rs.getInt("id"));
                post.setDescripcion(rs.getString("descripcion"));
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return post;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Obtiene las publicaciones creadas por un usuario dado de la tabla
     * PUBLICACIONES
     *
     * @param login login del usuario que ha creado la publicacion que se queire
     * obtener
     * @return publicacion creada por el usuario pasado
     */
    public static List<Post> getPostsUser(String login) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM PUBLICACION WHERE nombreUsuario = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, login);
            rs = ps.executeQuery();
            ArrayList<Post> posts = new ArrayList();
            while (rs.next()) {
                Post post = new Post();
                post.setFechaCreacion(rs.getString("fechaCreacion"));
                post.setTitulo(rs.getString("titulo"));
                post.setTexto(rs.getString("texto"));
                post.setNombreUsuario(rs.getString("nombreUsuario"));
                post.setVisualizaciones(rs.getInt("visualizaciones"));
                post.setReplicas(rs.getInt("hechos"));
                post.setValoraciones(rs.getInt("valoraciones"));
                post.setId(rs.getInt("id"));
                post.setDescripcion(rs.getString("descripcion"));
                posts.add(post);
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return posts;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<Post> getPostObject(Objeto objeto) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM PUBLICACION p, OBJETO_UTILIZADO ou WHERE ou.id_publicacion = p.id AND ou.nombre = ? ";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, objeto.getNombre());
            rs = ps.executeQuery();
            ArrayList<Post> posts = new ArrayList();
            while (rs.next()) {
                Post post = new Post();
                post.setFechaCreacion(rs.getDate("fechaCreacion").toString());
                post.setTitulo(rs.getString("titulo"));
                post.setTexto(rs.getString("texto"));
                post.setNombreUsuario(rs.getString("nombreUsuario"));
                post.setVisualizaciones(rs.getInt("visualizaciones"));
                post.setReplicas(rs.getInt("hechos"));
                post.setValoraciones(rs.getInt("valoraciones"));
                post.setId(rs.getInt("id"));
                post.setDescripcion(rs.getString("descripcion"));
                posts.add(post);
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return posts;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Obtiene las publicaciones guardadas por un usuario dado de la tabla
     * GUARDADO
     *
     * @param login del usario del que se quiere obtener la publicaicon guardada
     * @return publicaciones guardadas por el usuario dado
     */
    public static List<Post> getSavedPostsUser(String login) {

        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM GUARDADO G, PUBLICACION P WHERE G.id_publicacion = P.id AND G.login = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, login);
            rs = ps.executeQuery();
            ArrayList<Post> posts = new ArrayList();
            while (rs.next()) {
                Post post = new Post();
                post.setFechaCreacion(rs.getString("fechaCreacion"));
                post.setTitulo(rs.getString("titulo"));
                post.setTexto(rs.getString("texto"));
                post.setNombreUsuario(rs.getString("nombreUsuario"));
                post.setVisualizaciones(rs.getInt("visualizaciones"));
                post.setReplicas(rs.getInt("hechos"));
                post.setValoraciones(rs.getInt("valoraciones"));
                post.setId(rs.getInt("id"));
                post.setDescripcion(rs.getString("descripcion"));
                posts.add(post);
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return posts;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<Post> getAllPost() {

        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM PUBLICACION";
        try {
            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();
            ArrayList<Post> posts = new ArrayList();
            while (rs.next()) {
                Post post = new Post();
                post.setFechaCreacion(rs.getString("fechaCreacion"));
                post.setTitulo(rs.getString("titulo"));
                post.setTexto(rs.getString("texto"));
                post.setNombreUsuario(rs.getString("nombreUsuario"));
                post.setVisualizaciones(rs.getInt("visualizaciones"));
                post.setReplicas(rs.getInt("hechos"));
                post.setValoraciones(rs.getInt("valoraciones"));
                post.setId(rs.getInt("id"));
                post.setDescripcion(rs.getString("descripcion"));
                posts.add(post);
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return posts;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Inserta en la BD un nuevo post guardado en la tabla GUARDADO
     *
     * @param post que se quiere guardar en el la BD
     * @return numero de filas afectadas
     */
    public static int insertSavedPosts(Post post) {

        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "INSERT INTO GUARDADO (id_publicacion, login) VALUES (?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, post.getId());
            ps.setString(2, post.getNombreUsario());
            int res = ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     * Obtiene los objetos usados en una publicacion dada
     *
     * @param id id de la publicaciónd ela que se quiere obtener los objetos
     * guardados
     * @return lista de objetos usados en el post
     */
    public static List<Objeto> getUsedObjectPost(int id) {

        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT * FROM OBJETO_UTILIZADO OU, OBJETO O WHERE OU.nombre = O.nombre AND OU.id_publicacion = ?";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            ArrayList<Objeto> objects = new ArrayList();
            while (rs.next()) {
                Objeto object = new Objeto();
                object.setNombre(rs.getString("nombre"));
                objects.add(object);
            }
            rs.close();
            ps.close();
            pool.freeConnection(connection);
            return objects;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Inserta un objeto dado en la tabla OBJETO_UTILIZADO
     *
     * @param id de la publicacion en la que se usa el objeto
     * @param object objeto que se quiere guardar
     * @return numero de filas afectadas
     */
    public static int insertUsedObjectPost(int id, Objeto object) {

        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "INSERT INTO OBJETO_UTILIZADO (id_publicacion, nombre) VALUES (?, ?)";
        try {
            ps = connection.prepareStatement(query);
            ps.setInt(1, id);
            ps.setString(2, object.getNombre());
            int res = ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     * Selecciona la foto de la publicación dada
     *
     * @param id de la publicacion de a que se queire la foto
     * @param foto será donde se guarde la foto sacada de la BD
     */
    public static void getFoto(int id, OutputStream foto) {

        try {
            ConnectionPool pool = ConnectionPool.getInstance();
            Connection connection = pool.getConnection();
            PreparedStatement ps = null;
            ResultSet rs = null;
            String selectObjeto = "SELECT  foto  FROM PUBLICACION WHERE id = ?";
            ps = connection.prepareStatement(selectObjeto);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
                Blob blob = rs.getBlob("foto");
                if (!rs.wasNull() && blob.length() > 1) {
                    InputStream imagen = blob.getBinaryStream();
                    byte[] buffer = new byte[1000];
                    int len = imagen.read(buffer);
                    while (len != -1) {
                        foto.write(buffer, 0, len);
                        len = imagen.read(buffer);
                    }
                    imagen.close();
                }

            }
        } catch (IOException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Elimina la publicacion correspondiente al id dado
     *
     * @param id de la publicacion que se queire eliminar
     * @return número de filas afectadas
     */
    public static int removePost(int id) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        PreparedStatement psR = null;
        String queryR = "DELETE FROM PUBLICACION WHERE id = ?";

        try {
            psR = connection.prepareStatement(queryR);
            psR.setInt(1, id);
            int rs = psR.executeUpdate();

            psR.close();
            pool.freeConnection(connection);
            return rs;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;

        }

    }

    /**
     *
     * @param post
     * @return numero de filas afectadas
     */
    public static int updateInfo(Post post) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String addInfo = "UPDATE PUBLICACION SET foto =?, titulo = ?, texto = ?, descripcion = ?  WHERE id = ?";

        try {
            ps = connection.prepareStatement(addInfo, Statement.RETURN_GENERATED_KEYS);
            ps.setBlob(1, post.getFoto().getInputStream());
            ps.setString(2, post.getTitulo());
            ps.setString(3, post.getTexto());
            ps.setString(4, post.getDescripcion());
            ps.setInt(5, post.getId());
            int rs = ps.executeUpdate();

            ps.close();

            pool.freeConnection(connection);

            return rs;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } catch (IOException ex) {
            Logger.getLogger(UsuarioDB.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }

    }

    /**
     *
     * @param id
     * @param visualizaciones
     * @return numero de filas afectadas
     */
    public static int updateVisualizaciones(int id, int visualizaciones) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "UPDATE PUBLICACION SET visualizaciones = ? WHERE id=?";

        try {
            ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, visualizaciones);
            ps.setInt(2, id);

            int rs = ps.executeUpdate();

            ps.close();

            return rs;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     *
     * @param id
     * @param hechos
     * @return numero de filas afectadas
     */
    public static int updateHechos(int id, int hechos) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "UPDATE PUBLICACION SET hechos = ? WHERE id=?";

        try {
            ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, hechos);
            ps.setInt(2, id);

            int rs = ps.executeUpdate();

            ps.close();

            return rs;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     *
     * @param id
     * @param valoraciones
     * @return numero de filas afectadas
     */
    public static int updateValoraciones(int id, int valoraciones) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String query = "UPDATE PUBLICACION SET valoraciones = ? WHERE id=?";

        try {
            ps = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, valoraciones);
            ps.setInt(2, id);

            int rs = ps.executeUpdate();

            ps.close();

            return rs;

        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }

    }

    /**
     * Cuenta el númeor de post que hay en el BD
     *
     * @return
     */
    public static int getNumPost() {

        try {
            ConnectionPool pool = ConnectionPool.getInstance();
            Connection connection = pool.getConnection();
            ResultSet rs = null;
            PreparedStatement ps = null;

            String query = "SELECT COUNT(*) as num FROM PUBLICACION";

            ps = connection.prepareStatement(query);
            rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getInt("num");
            }

        } catch (SQLException ex) {
            Logger.getLogger(PostDB.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

}
