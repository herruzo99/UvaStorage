package rerego.datos.dao;

import java.io.IOException;

import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import rerego.datos.ConnectionPool;
import rerego.model.Objeto;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class ObjetoDB {
    /**
     * Para insertar Objetos en la base de datos.
     * 
     * @param objeto
     * @return 
     */
    public static int insert(Objeto objeto){
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String createObject = "INSERT INTO OBJETO (nombre, foto) VALUES (?, ?)";
                try {
            ps = connection.prepareStatement(createObject);
            ps.setString(1, objeto.getNombre());
            ps.setBlob(2, objeto.getFoto().getInputStream());
            
            ps.executeUpdate();
            ps.close();
            pool.freeConnection(connection);
            int res = updateInfo(objeto);
            return res;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } catch (IOException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }

    /**
     * Para insertar infoObjetos en la base de datos.
     * 
     * @param usuario
     * @return 
     */
    public static int updateInfo(Objeto objeto) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();

        PreparedStatement ps = null;

        String addInfo = "INSERT INTO INFOOBJETO (nombreObjeto, loginUsuario, como, descripcion, fechaCreacion, categoria) VALUES (?, ?, ?, ?, ?, ?)";
        String otrosNombres = "INSERT INTO OTROSNOMBRES (id, otroNombre) VALUES (?, ?)";
        String datosInteresantes = "INSERT INTO DATOSINTERESANTES (id, dato) VALUES (?, ?)";

        try {
            ps = connection.prepareStatement(addInfo, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, objeto.getNombre());
            ps.setString(2, objeto.getUsuario().getLogin());
            ps.setString(3, objeto.getComo());
            ps.setString(4, objeto.getDescripcion());
            ps.setDate(5, Date.valueOf(objeto.getFechaCreacion()));
            ps.setString(6, objeto.getCategoria().getNombre());
            ps.executeUpdate();
            
            int id = 0;
            ResultSet generatedKeys = ps.getGeneratedKeys();
            
            
            if (generatedKeys.next()) {
               id = generatedKeys.getInt(1);
            }
            
            ps.close();
            
            for(String nombre : objeto.getOtrosNombres()){
            ps = connection.prepareStatement(otrosNombres);
            ps.setInt(1, id);
            ps.setString(2, nombre);
            ps.executeUpdate();
            ps.close();
            }
            
            for(String dato : objeto.getDatosInteresantes()){
            ps = connection.prepareStatement(datosInteresantes);
            ps.setInt(1, id);
            ps.setString(2, dato);
            ps.executeUpdate();
            ps.close();
            }
            
            pool.freeConnection(connection);
            return 1;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
    
    /**
     * Para sacar usuarios de la base de datos.
     * 
     * @param login
     * @return 
     */
    public static Objeto selectObject(String nombre) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String selectObjeto = "SELECT * FROM OBJETO WHERE nombre = ?";
        String selectInfo = "SELECT * FROM INFOOBJETO WHERE nombreObjeto = ? ORDER BY id DESC";
        String selectNombre = "SELECT * FROM OTROSNOMBRES WHERE id = ?";
        String selectDatos = "SELECT * FROM DATOSINTERESANTES WHERE id = ?";
        try {
            ps = connection.prepareStatement(selectObjeto);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            Objeto objeto = new Objeto();
            if (rs.next()) {
                objeto.setNombre(rs.getString("nombre"));
            }
            rs.close();
            ps.close();
            
            ps = connection.prepareStatement(selectInfo);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            int id = 0;
            if (rs.next()) {
                id = rs.getInt("id");
                objeto.setUsuario(UsuarioDB.selectUser(rs.getString("loginUsuario")));
                objeto.setComo(rs.getString("como"));
                objeto.setDescripcion(rs.getString("descripcion"));
                objeto.setFechaCreacion(rs.getDate("fechaCreacion").toString());
                objeto.setCategoria(CategoriaDB.selectCategoria(rs.getString("categoria")));
            }else{
                return null;
            }
            rs.close();
            ps.close();
            
            ps = connection.prepareStatement(selectNombre);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            ArrayList<String> nombres = new ArrayList();
            while (rs.next()) {
                nombres.add(rs.getString("otroNombre"));
            }
            objeto.setOtrosNombres(nombres);
            rs.close();
            ps.close();
            
            ps = connection.prepareStatement(selectDatos);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            ArrayList<String> datos = new ArrayList();
            while (rs.next()) {
                datos.add(rs.getString("dato"));
            }
            objeto.setDatosInteresantes(datos);
            rs.close();
            ps.close();
            
            pool.freeConnection(connection);
            
            return objeto;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * 
     * @param nombre pk del objeto
     * @param foto aqui queda guardad la foto del objeto
     */
     public static void getFoto (String nombre, OutputStream foto) {
        try{
             ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String selectObjeto = "SELECT foto FROM OBJETO WHERE nombre = ?";
        ps = connection.prepareStatement(selectObjeto);
        ps.setString(1, nombre);
        rs = ps.executeQuery();
        
        if(rs.next()){
            Blob blob = rs.getBlob("foto");
            if(!rs.wasNull() && blob.length() > 1){
                InputStream imagen = blob.getBinaryStream();
                byte[] buffer = new byte[1000];
                int len = imagen.read(buffer);
                while (len != -1){
                    foto.write(buffer,0, len);
                    len = imagen.read(buffer);
                }
                imagen.close();
            }

        }
        
        } catch (IOException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(ObjetoDB.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
     public static List<Objeto> getObjectCategory(String nombre) {
        ConnectionPool pool = ConnectionPool.getInstance();
        Connection connection = pool.getConnection();
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "SELECT distinct o.nombre FROM OBJETO o, CATEGORIA c, INFOOBJETO i WHERE i.nombreObjeto = o.nombre AND i.categoria = ?";

        try {
            ps = connection.prepareStatement(query);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            ArrayList<Objeto> objetos = new ArrayList<>();
            
            if (rs.next()) {
                objetos.add(selectObject(rs.getString("nombre")));
            }
            
            rs.close();
            ps.close();
            
            return objetos;
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }     
}
