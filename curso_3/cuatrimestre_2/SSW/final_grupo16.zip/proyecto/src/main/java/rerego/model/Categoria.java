package rerego.model;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class Categoria implements Serializable {

	private String nombre;
	private String descripcion;
	private String color;
	private ArrayList<PuntoGPS> puntosGPS;

	public Categoria() {
		nombre = "";
		descripcion = "";
		color = "";
		puntosGPS = null;
	}

	public Categoria(String nombre, String descripcion, String color, ArrayList<PuntoGPS> puntosGPS) {
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.color = color;
		this.puntosGPS = puntosGPS;
	}

	/**
	 * @return the color
	 */
	public String getColor() {
		return color;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}



	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @return the puntosGPS
	 */
	public ArrayList<PuntoGPS> getPuntosGPS() {
		return puntosGPS;
	}

	/**
	 * @param color the color to set
	 */
	public void setColor(String color) {
		this.color = color;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}


	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @param puntosGPS the puntosGPS to set
	 */
	public void setPuntosGPS(ArrayList<PuntoGPS> puntosGPS) {
		this.puntosGPS = puntosGPS;
	}

}
