package rerego.model;

import java.io.Serializable;
import java.util.List;
import javax.servlet.http.Part;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class Objeto implements Serializable {
	private String nombre;
	private Usuario usuario;
	private String como;
	private String descripcion;
	private Part foto;
	private String fechaCreacion;
	private Categoria categoria;
	private List<String> otrosNombres;
	private List<String> datosInteresantes;

	public Objeto() {
		nombre = "";
		usuario = null;
		como = "";
		descripcion = "";
		foto = null;
		fechaCreacion = "";
		categoria = null;
		otrosNombres = null;
		datosInteresantes = null;

	}

	public Objeto(String nombre, Usuario usuario, String como, String descripcion, Part foto,
			String fechaCreacion, Categoria categoria, List<String> otrosNombres, List<String> datosInteresantes) {
		this.nombre = nombre;
		this.usuario = usuario;
		this.como = como;
		this.descripcion = descripcion;
		this.foto = foto;
		this.fechaCreacion = fechaCreacion;
		this.categoria = categoria;
		this.otrosNombres = otrosNombres;
		this.datosInteresantes = datosInteresantes;
	}

	/**
	 * @return the categoria
	 */
	public Categoria getCategoria() {
		return categoria;
	}

	/**
	 * @return the como
	 */
	public String getComo() {
		return como;
	}

        /**
	 * @return the datosInteresantes
	 */
	public List<String> getDatosInteresantes()  {
		
		return datosInteresantes;
	}
        
	/**
	 * @return the datosInteresantes
	 */
	public String getDatosInteresantesToEdit() {
		String datos = "";
		for (String dato : getDatosInteresantes()) {
			datos += dato;
			datos += ";";
		}
		return datos;
	}

	/**
	 * @return the descripcion
	 */
	public String getDescripcion() {
		return descripcion;
	}

	/**
	 * @return the fechaCreacion
	 */
	public String getFechaCreacion() {
		return fechaCreacion;
	}

	/**
	 * @return the foto
	 */
	public Part getFoto() {
		return foto;
	}

	/**
	 * @return the login
	 */
	public String getNombre() {
		return nombre;
	}


        /**
	 * @return the otrosNombres
	 */
	public List<String> getOtrosNombres()  {
		
		return otrosNombres;
	}
        
	/**
	 * @return the otrosNombres
	 */
	public String getOtrosNombresToEdit() {
		String nombres = "";
		for (String nombre : getOtrosNombres()) {
			nombres += nombre;
			nombres += ";";
		}
		return nombres;
	}
        
	/**
	 * @return the usuario
	 */
	public Usuario getUsuario() {
		return usuario;
	}

	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}

	/**
	 * @param como the como to set
	 */
	public void setComo(String como) {
		this.como = como;
	}

	/**
	 * @param datosInteresantes the datosInteresantes to set
	 */
	public void setDatosInteresantes(List<String> datosInteresantes) {
		this.datosInteresantes = datosInteresantes;
	}

	/**
	 * @param descripcion the descripcion to set
	 */
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	/**
	 * @param foto the foto to set
	 */
	public void setFoto(Part foto) {
		this.foto = foto;
	}



	/**
	 * @param nombre the login to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @param otrosNombres the otrosNombres to set
	 */
	public void setOtrosNombres(List<String> otrosNombres) {
		this.otrosNombres = otrosNombres;
	}

	/**
	 * @param usuario the usuario to set
	 */
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}

}
