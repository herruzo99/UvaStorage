/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control;

import rerego.control.users.utility.CookiesKitchen;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import rerego.datos.dao.ObjetoDB;
import rerego.datos.dao.PostDB;
import rerego.model.Categoria;
import rerego.model.Objeto;
import rerego.model.Post;
import rerego.model.Usuario;

/**
 *
 * @author rebeca
 */
@WebServlet(name = "IndexServlet", urlPatterns = {""})
public class IndexServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Usuario usuario = CookiesKitchen.GetUser(request, response);

        int numPost = PostDB.getNumPost();
        Random rand = new Random();
        int num;

        ArrayList<Post> publicaciones = new ArrayList();
        ArrayList<Post> allPost = new ArrayList(PostDB.getAllPost());
        ArrayList<Integer> numRandom = new ArrayList();
        numRandom.add(rand.nextInt(numPost));

        int j = 0;
        while (j < 3) {
            num = rand.nextInt(numPost);
            if (!numRandom.contains(num)) {
                numRandom.add(num);
                j++;
            }
        }
        for (int i = 0; i < 3; i++) {
            publicaciones.add(allPost.get(numRandom.get(i)));
        }
        if (usuario != null) {
            request.setAttribute("usuario", usuario);
        }
        request.setAttribute("publicaciones", publicaciones);

        String url = "/index.jsp";
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
        dispatcher.forward(request, response);

    }
}
