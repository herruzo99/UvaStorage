/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rerego.control.users;

import rerego.control.users.utility.CookiesKitchen;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;
import rerego.datos.dao.UsuarioDB;
import rerego.model.Usuario;

/**
 *
 * @author pablojp
 */
@WebServlet(name = "CambiarPassServlet", urlPatterns = {"/cambiarpass"})
@MultipartConfig
public class CambiarPassServlet extends HttpServlet {

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario == null) {
            // Si no hay usuario redirigimos a iniciarsesion
            response.sendRedirect("/rerego/iniciarsesion");
        } else {
            // Si hay usuario mostramos cambiarpass.jsp

            request.setAttribute("usuario", usuario);

            String url = "/user/cambiarpass.jsp";
            RequestDispatcher dispatcher = getServletContext().getRequestDispatcher(url);
            dispatcher.forward(request, response);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Usuario usuario = CookiesKitchen.GetUser(request, response);
        if (usuario == null) {
            // Si no hay usuario redirigimos a iniciarsesion
            response.sendRedirect("/rerego/iniciarsesion");
        } else {
            request.setCharacterEncoding("UTF-8");
            // Si hay usuario procedemos a actualizar la contraseña
            String username = usuario.getLogin();
            String oldpassword = request.getParameter("oldpassword");
            String password = request.getParameter("password");
            String repassword = request.getParameter("repassword");
            String name = request.getParameter("name");
            if (name == null || name.isEmpty()) {
                name = username;
            }
            String description = request.getParameter("description");
            Part photo = request.getPart("photo");
            boolean error = false;
            String mensajeError = "";
            if (!usuario.getPass().equals(Usuario.getSecurePassword(oldpassword))) {
                // Contraseña actual no válida
                error = true;
                mensajeError += "La contraseña actual es incorrecta.<br/>";
            }
            if (password.length() < 8 || password.length() > 20) {
                // Contraseña nueva no válida
                error = true;
                mensajeError += "La contraseña nueva tiene que tener entre 8 y 20 caracteres.<br/>";
            }
            if (!password.equals(repassword)) {
                // Las contraseñas no coinciden
                error = true;
                mensajeError += "La contraseña nueva no coincide.<br/>";
            }
            HttpSession session = request.getSession();
            if (error == true) {
                session.setAttribute("mensajeError", mensajeError);
                response.sendRedirect("/rerego/cambiarpass");
            } else {
                // Todo correcto, actualizamos la password
                usuario.setPass(Usuario.getSecurePassword(password));
                UsuarioDB.updatePass(usuario);
                response.sendRedirect("/rerego/perfil");
            }
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
