package rerego.model;

import java.io.Serializable;

/**
 * @author rebhern
 * @author juaherr
 * @author pabjime
 * @author pabredo
 */
public class PuntoGPS implements Serializable {

	private Float longitud;
	private Float latitud;
	private String fechaCreacion;

	public PuntoGPS() {
		longitud = 0.0f;
		latitud = 0.0f;
		fechaCreacion = "";
	}

	public PuntoGPS(Float longitud, Float latitud, String fechaCreacion) {
		this.longitud = longitud;
		this.latitud = latitud;
		this.fechaCreacion = fechaCreacion;
	}



	/**
	 * @return the fechaCreacion
	 */
	public String getFechaCreacion() {
		return fechaCreacion;
	}

	/**
	 * @return the latitud
	 */
	public Float getLatitud() {
		return latitud;
	}

	/**
	 * @return the longitud
	 */
	public Float getLongitud() {
		return longitud;
	}



	/**
	 * @param fechaCreacion the fechaCreacion to set
	 */
	public void setFechaCreacion(String fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	/**
	 * @param latitud the latitud to set
	 */
	public void setLatitud(Float latitud) {
		this.latitud = latitud;
	}

	/**
	 * @param longitud the longitud to set
	 */
	public void setLongitud(Float longitud) {
		this.longitud = longitud;
	}

	@Override
	public String toString() {
		String datos = "";
		datos += latitud + "|";
		datos += longitud;
		return datos;
	}
}
