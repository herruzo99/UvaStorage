let categoria = document.currentScript.getAttribute('contenedor');
let puntos = document.currentScript.getAttribute('puntos');

let contenedor;
let locationsInfo;

const getLocations = (puntos, categoria) => {
    locationsInfo = [];
    puntos = puntos.substring(1, puntos.length-1).split(", ");

    puntos.forEach(punto => {
        let data = punto.split("|");
        let locationData = {
            position: {lat: Number(data[0]), lng: Number(data[1])}        };

        locationsInfo.push(locationData);
    });
    contenedor = "images/iconos/"+ categoria+".png";
    initMap(locationsInfo);
};



// Note: This example requires that you consent to location sharing when
// prompted by your browser. If you see the error "The Geolocation service
// failed.", it means you probably did not give permission for the browser to
// locate you.

function initMap() {
    
    let map;
    map = new google.maps.Map(document.getElementById('map'), {
        center: {lat: 41.638177, lng: -4.760635},
        zoom: 12
    });
    map.setOptions({
        styles: [
            {
                featureType: 'poi.business',
                stylers: [{visibility: 'off'}]
            },
            {
                featureType: 'transit',
                elementType: 'labels.icon',
                stylers: [{visibility: 'off'}]
            }
        ]
    });

    // Try HTML5 geolocation.
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            map.setCenter(pos);
        });
    }

    locationsInfo.map((place) => {



        var marker = new google.maps.Marker({
            position: place.position,
            map: map,
            icon: contenedor
        });
        console.log(place);
        marker.addListener('click', function () {
            infowindow.open(map, marker);
        });
        return marker
    })
}

getLocations(puntos, categoria);
