let categoria = document.currentScript.getAttribute('contenedor');
let puntos = document.currentScript.getAttribute('puntos');

let contenedor;
let locationsInfo;
let locationsInfo_output;

const getLocations = (puntos, categoria) => {
    locationsInfo = [];
    locationsInfo_output = [];
        console.log(puntos);
     if(puntos !== "[]"){
    puntos = puntos.substring(1, puntos.length-1).split(", ");
     
    puntos.forEach(punto => {
        let data = punto.split("|");
        let locationData = {
            position: {lat: Number(data[0]), lng: Number(data[1])}        };

        locationsInfo.push(locationData);
    });
     }
    contenedor = "images/iconos/"+ categoria+".png";
    initMap(locationsInfo);
};

// Note: This example requires that you consent to location sharing when
// prompted by your browser. If you see the error "The Geolocation service
// failed.", it means you probably did not give permission for the browser to
// locate you.

function initMap() {
    map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: 41.638177, lng: -4.760635 },
        zoom: 12
    });
    map.setOptions({
        styles: [
            {
                featureType: 'poi.business',
                stylers: [{ visibility: 'off' }]
            },
            {
                featureType: 'transit',
                elementType: 'labels.icon',
                stylers: [{ visibility: 'off' }]
            }
        ]
    });

    // Try HTML5 geolocation.
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function (position) {
            var pos = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            map.setCenter(pos);
        });
    }

    locationsInfo.map((place) => {
       placeMarker(place);
       locationsInfo_output.push(place.position.lat + "," + place.position.lng);
    });
    let coordinate_form = document.getElementById('coodinates_form');
    coordinate_form.value = locationsInfo_output.join(";");
        
    map.addListener('click', function (event) {
        let place = {position: {lat: event.latLng.lat(), lng: event.latLng.lng()}};
        placeMarker(place);
        locationsInfo.push(place);
        locationsInfo_output.push(event.latLng.lat() + "," + event.latLng.lng());
        let coordinate_form = document.getElementById('coodinates_form');
        coordinate_form.value = locationsInfo_output.join(";");
    });


}


function placeMarker(location) {
    var marker = new google.maps.Marker({
        position: location.position,
        map: map,
        icon: contenedor
    });

    marker.addListener('click', function () {
        marker.setMap(null);
                        console.log(marker.position.lat() +" | "+marker.position.lng());
                console.log("VS");
        var i = 0;
        while (i < locationsInfo.length) {
            if (locationsInfo[i].position.lat === marker.position.lat() && locationsInfo[i].position.lng === marker.position.lng()) {
                                console.log(i);

                locationsInfo.splice(i, 1)
                locationsInfo_output.splice(i,1);
                i = locationsInfo.length;
            }
            i++;
        }

        let coordinate_form = document.getElementById('coodinates_form');
        coordinate_form.value = locationsInfo_output.join(";");


    });
}

getLocations(puntos, categoria);

