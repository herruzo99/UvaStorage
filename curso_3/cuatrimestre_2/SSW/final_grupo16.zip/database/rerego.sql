SET FOREIGN_KEY_CHECKS=0;
DROP TABLE USUARIO;
DROP TABLE OBJETO;
DROP TABLE INFOOBJETO;
DROP TABLE OTROSNOMBRES;
DROP TABLE DATOSINTERESANTES;
DROP TABLE CATEGORIA;
DROP TABLE PUNTOGPS;
DROP TABLE PUBLICACION;
DROP TABLE GUARDADO;
DROP TABLE OBJETO_UTILIZADO;

SET FOREIGN_KEY_CHECKS=1;

create table USUARIO
(
	login VARCHAR(20) not null,
	pass VARCHAR(512) not null,
	nombre VARCHAR(20) not null,
	email VARCHAR(50) not null unique,
	fechaCreacion DATE not null,
	descripcion VARCHAR(256),
	foto MEDIUMBLOB,
	PRIMARY KEY(login)
);

create table CATEGORIA
	(
		nombre VARCHAR(20) not null,
		foto MEDIUMBLOB not null,
                                    icono MEDIUMBLOB not null,
                                    color VARCHAR(20),
		descripcion VARCHAR(256),
		PRIMARY KEY (nombre)
	);

create table OBJETO
(
	nombre VARCHAR(20) not null,
	foto MEDIUMBLOB,
		PRIMARY KEY(nombre)
);

create table INFOOBJETO
(
	id INT AUTO_INCREMENT,
	nombreObjeto VARCHAR(20) not null,
	loginUsuario VARCHAR(20) not null,
	como VARCHAR(2000),
	descripcion VARCHAR(256),
	fechaCreacion DATE not null,
	categoria VARCHAR(20) not null,
		PRIMARY KEY (id),
		FOREIGN KEY (nombreObjeto) REFERENCES OBJETO(nombre),
		FOREIGN KEY (categoria) REFERENCES CATEGORIA(nombre),
                FOREIGN KEY (loginUsuario) REFERENCES USUARIO(login) ON DELETE CASCADE ON UPDATE CASCADE
);

create table OTROSNOMBRES
	(
		id INT not null,
		otroNombre VARCHAR(20),
		FOREIGN KEY (id) REFERENCES INFOOBJETO(id),
		PRiMARY KEY (id, otroNombre)

	);

create table DATOSINTERESANTES
	(
		id INT not null,
		dato VARCHAR(240),
		FOREIGN KEY (id) REFERENCES INFOOBJETO(id) ON DELETE CASCADE,
		PRiMARY KEY (id, dato)

	);


create table PUNTOGPS
	(
		id INT AUTO_INCREMENT,
		longitud FLOAT(24),
		latitud FLOAT(24),
		fechaCreacion DATE not null,
		categoria VARCHAR(20),
			PRIMARY KEY(id),
			FOREIGN KEY (categoria) REFERENCES CATEGORIA(nombre)
	);

create table PUBLICACION
	(
		id INT AUTO_INCREMENT,
		foto MEDIUMBLOB,
		nombreUsuario VARCHAR(20),
		titulo VARCHAR(80) not null,
		texto VARCHAR(2000) not null,
                                    descripcion VARCHAR(300),
		visualizaciones INT,
		valoraciones INT,
                                    hechos INT,
		fechaCreacion DATE not null,
			PRIMARY KEY(id),
			FOREIGN KEY(nombreUsuario) REFERENCES USUARIO(login) ON DELETE CASCADE
	);
create table GUARDADO
        (
        id_publicacion INT,
        login VARCHAR(20),
        PRIMARY KEY(id_publicacion, login),
        FOREIGN KEY(id_publicacion) REFERENCES PUBLICACION(id) ON DELETE CASCADE,
	FOREIGN KEY(login) REFERENCES USUARIO(login)  ON DELETE CASCADE

        );

create table OBJETO_UTILIZADO
(
        id_publicacion INT,
        nombre VARCHAR(20),
        PRIMARY KEY(id_publicacion, nombre),
        FOREIGN KEY(id_publicacion) REFERENCES PUBLICACION(id) ON DELETE CASCADE,
	FOREIGN KEY(nombre) REFERENCES OBJETO(nombre)

);

INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion)
VALUES ('hecgon','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','Héctor González', 'hectorgonzalez@gmail.com','2020-03-03');


INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion)
VALUES ('oscarg','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','Oscar Gómez', 'oscargomez@gmail.com','2019-11-03');


INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion, descripcion)
VALUES ('luis3','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','Luisito', 'luis.rodriguez@alumnos.uva.es','2019-10-02', 'Hola soy Luis y quiero todo lo que sepueda sobre reciclaje y reutilización.');

INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion)
VALUES ('beap','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','Bea Pardo', 'beapardo@gmail.com','2019-10-02');

INSERT INTO USUARIO(login, pass, nombre, email, fechaCreacion, foto, descripcion)
VALUES ('admin','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','Administrador', 'admin@rere.go','2019-10-02', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/usuarios/perfil.png'), 'Administrador todopoderoso benevolente para siempre.'),
('ghost','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86','Cuenta eliminada', 'ghost@rere.go','2019-10-02',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/usuarios/ghost.png'), 'Cuenta fantasma que se sustituye a las cuentas eliminadas.');

--Objetos
INSERT INTO OBJETO(nombre,foto)
VALUES ('default',null),
('bolígrafo',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/bolígrafo.jpeg')),
('cascara de naranja',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/cascara de naranja.jpg')),
('cartón',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/cartón.jpg')),
('televisor',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/televisor.png')),
('ropa textil',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/ropa textil.jpg')),
('botella',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/botella.jpg')),
('lata', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/lata.png')),
('aerosol', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/aerosol.jpg')),
('brick', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/brick.jpg')),
('caja de cartón',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/caja de cartón.jpg')),
('periódico',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/periódico.jpg')),
('libro',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/libro.jpg')),
('huevera',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/huevera.jpg')),
('botella de cristal', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/botella de cristal.jpg')),
('tarro',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/tarro.jpg')),
('colonia',null),
('restos de comida',null),
('flores',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/flores.jpg')),
('hojas',null),
('corcho',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/corcho.jpg')),
('serrín',null),
('electrodoméstico',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/electrodoméstico.jpeg')),
('escombros',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/escombros.jpg')),
('CD',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/CD.jpg')),
('VHS',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/VHS.jpg')),
('pintura',LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/objetos/pintura.jpg')),
('aceite doméstico',null);

--Categorias
INSERT INTO CATEGORIA	( nombre, foto, icono, color, descripcion)
VALUES ('orgánico', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/imagenes/organico.png'),LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/iconos/organico.png'), '#990', 'En esta categoría se destinan todos los objetos orgánicos, es decir, objetos con compuestos orgánicos que provienen de los restos de organismos que alguna vez estuvieron vivos, tales como plantas, animales...'),
('inorgánico', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/imagenes/inorganico.png'),LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/iconos/inorganico.png'),'#999', 'En esta categoría se inclullen los objetos hecho con materiales que no está hechos de carbono y no son fabricados por los seres vivos, sino por reacciones químicas.'),
('punto limpio', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/imagenes/punto limpio.png'),LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/iconos/organico.png'),'#777', 'Al punto limpio se destinan los objetos de composición de estos residuos, que puede llegar a ser tóxica y que es esencial separar de los de otro tipo.'),
('papel y cartón', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/imagenes/papel y carton.png'),LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/iconos/papel y carton.png'),'#44F', 'En esta categoría todos los objetos hechos de papel y cartón.'),
('vidrio', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/imagenes/vidrio.png'),LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/categoria/iconos/vidrio.png'), '#4F4', 'En esta categoría todos los objetos hechos de vidrio.');

--InfoObjeto
INSERT INTO INFOOBJETO( nombreObjeto,loginUsuario, como, descripcion, fechaCreacion,categoria)
VALUES('default', 'admin', '', '', '1970-01-01', 'inorgánico'),
('lata', 'admin', 'Contedor amarillo', 'Las latas se reciclan vacías en	el contenedor amarillo. Este contenedor está destinado al reciclaje de envases.', '2019-02-02', 'inorgánico'),
('bolígrafo','admin', 'Una vez gastada la tinta del bolígrafo se puede reciclar en el los puntos limpios,','Se utiliza para pintar', '2019-02-02','punto limpio' ),
('cascara de naranja','luis3',' se puede tirar directamente al orgánico', 'cascara de naranja, es decir, el exterior', '2020-02-12', 'orgánico' ),
('cartón','oscarg', 'El cartón ha de ir al contenedor azul, es el mismo que el de papel','Suele ser utilizado para enbalar, mas resistente que el papel','2020-04-12','papel y cartón' ),
('televisor','beap', 'Puedes llevarlo al punto limpio de	tu ciudad o puedo o llamar para que te lo recojan en casa.','Una television, sirve para poder ver vídeos','2020-04-12', 'punto limpio' ),
('ropa textil','beap', 'Se puede tirar directamente al contenedor de inorganico aunque es mas recomendable donarla.','ropa de cualquier tipo que contenga textil','2020-03-12', 'punto limpio' ),
('botella','luis3', 'Directamente al contenedor amarillo, también puedes guardar el tapón y utilizarlo en causas benéficas','botellas de plástico de cualquier tipo','2020-02-12', 'inorganico' ),
('aerosol','admin','Contenedor de envases','El envasado de aerosoles consiste en una formulación o modo de dispensar sustancias de naturaleza normalmente líquida.', '2020-05-25','inorgánico'),
('brick', 'oscarg','Se recicla en el contenedor de envases',' ','2020-05-25','inorganico'),
('caja de cartón','luis3','Siempre que la caja de cartón habrá que reciclarla en el contendor de azul', ' ', '2020-04-24','papel y cartón'),
('periódico','admin',' ',' ','2020-05-25', 'papel y cartón'),
('huevera','beap',' ',' ','2020-03-03','papel y cartón'),
('botella de cristal','admin',' ',' ','2020-02-02','vidrio'),
('tarro','admin',' ',' ','2020-02-02','vidrio'),
('colonia','admin',' ',' ','2020-02-02','vidrio'),
('flores','beap',' ',' ','2020-05-25','organico'),
('corcho','beap',' ',' ','2020-05-25','orgánico'),
('serrín','oscarg',' ',' ','2020-05-25','orgánico'),
('electrodoméstico','oscarg',' ',' ','2020-05-25','punto limpio'),
('escombros','oscarg',' ',' ','2020-05-25','punto limpio'),
('CD','luis3',' ',' ','2020-05-25','punto limpio'),
('VHS','luis3',' ',' ','2020-05-25','punto limpio'),
('pintura','luis3',' ',' ','2020-05-25','punto limpio'),
('aceite doméstico','luis3',' ',' ','2020-05-25','punto limpio');
--OTROSNOMBRES
INSERT INTO OTROSNOMBRES(id,otroNombre)
VALUES ('5', 'tele'),
('4', 'cartulina'),
('3', 'fruta'),
('3', 'piel de fruta'),
('3', 'cascara'),
('3', 'comida'),
('2', 'refresco'),
('9','desodorante'),
('9','insecticida'),
('10', 'brick de zumo'),
('10', 'brick de leche'),
('10','brick de gazpacho'),
('10','brick de caldo'),
('11','caja de galletas'),
('11','caja de cereales'),
('12', 'revista'),
('14', 'frasco'),
('15','fragancia'),
('15','perfume'),
('17','planta'),
('24','cinta'),
('24','película');

--DATOSINTERESANTES
INSERT INTO DATOSINTERESANTES	(id,	dato )
VALUES ('3', 'Los bolígrafos más sostenibles y que menos perjudican almedio ambiente son los recargables');

--PUNTOGPS
INSERT INTO PUNTOGPS ( longitud, latitud, fechaCreacion, categoria)
VALUES('-4.7237200', '41.6551800', '2020-02-12','orgánico'),
('-4.7503400', '41.6547100', '2020-02-02','inorgánico'),
('-4.72850275', '41.65227127', '2020-01-02','punto limpio'),
('-4.7257100', '41.6424200', '2020-01-02','inorgánico'),
( '-4.7325','41.645556', '2020-01-02','orgánico');

--PUBLICACION
INSERT INTO PUBLICACION	(nombreUsuario,	titulo,	texto, visualizaciones, valoraciones, hechos, foto, fechaCreacion, descripcion)
--Publicacion 1
VALUES('hecgon', 'Luces y macetas de jardín con latas.','Una forma muy original de reaprovechar latas es convertirlas en lámparas de exterior que ofrecen una
              luz íntima y perfecta para las veladas más relajadas. Para ello, tan solo tendrás que buscar las
              latas de conserva que pueden ser de todos los tamaños, límpialas con abundante agua y jabón y
              sécalas.
							Después, tendrás que meterlas en el congelador para poder
              darle el diseño
              que buscas y hacerle los agujeros fácilmente. Antes de meterla dentro del congelador tendrás que
              rellenar 3/4 de lata para evitar que se deforme con el frío, déjala una hora, aproximadamente, hasta
              que el agua esté completamente congelada.
							A continuación tan solo tienes que perforarla con unos clavos siguiendo el
              diseño que prefieras: un sol, un espiral, la luna, etcétera. Tendrás que clavar los clavos siguiendo
              el dibujo que buscas y después sacarlos con cuidado para que no se rompa. Una vez listo, puedes
              darle una capa de pintura y decorar a tu gusto tu lámpara hecha con latas. Introduce una vela en su
              interior ¡y listo!','10562','4530','123', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/lata.jpg'), '2020-04-04', 'Una idea sencilla para reutilizar latas de conserva'),
--Publicacion 2
('beap', 'Rallador y Organizador de escritorio con latas','Si acabas de mudarte y no tienes un rallador para preparar tu ensalada favorita, o agregar queso a tus pastas, puedes improvisar uno con una lata de conservas, levemente hundida hacia adentro y con orificios a intervalos regulares. Asegúrate de que esté bien limpia y de limar bien los agujeros para que nada del aluminio pase a tus comidas.
	Si tomas algunas latas de conservas, las limpias bien y las envuelves con un papel de un estampado bonito, puedes crear un organizador de escritorio práctico y original, donde colocar tus lápices y otros útiles. Solo debes apilar las latas juntas y unirlas con ayuda de una pistola encoladora.',
        '1562','430','13', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/rallador.jpg'),'2020-04-04', 'Decora tu despacho habitación y cocina con esta sencilla idea'),
--Publicaion 3
('beap', '10 maneras originales de reciclar ropa','1. Los jerséis te abrigan en invierno pero llega un momento que se llenan de bolitas y se desgastan por algunas zonas. Con un poco de aguja e hilo, puedes convertir ese jersey en unos calentitos guantes para el invierno aprovechando el tejido.
<br/>2. Si tienes una mascota, seguro que habrás pensado en comprarle una camita, pero ¿por qué no hacerla tú mismo? Con un jersey viejo y un poco de algodón de relleno, puedes hacer una cómoda cama para tu gato o perro.
<br/>3. Ya que hablamos de jerséis, si con la tela hemos fabricado unos guantes, con las mangas podemos hacer unos calentadores a juego, para llevar con botas de caña alta y no pasar frío en los meses más duros del invierno.
<br/>4. Si tienes varias camisetas de algodón que te aburren pero lo tuyo no es coser precisamente, puedes crear diversos patrones originales con paciencia y un par de tijeras, para lucir unas bonitas camisetas en verano.
<br/>5. Para los más pequeños también hay ideas. ¿Por qué no convertir los calcetines viejos o las camisetas en adorables peluches?
<br/>6. De las camisetas de algodón de colores podemos conseguir el famoso trapillo, con el que realizar verdaderas obras de arte mediante su trenzado.
<br/>7. Con un poco de cinta de carrocero y pintura para ropa, animarás esos aburridos zapatos que ya no te ponías.
<br/>8. Una corbata también puede convertirse en algo nuevo y útil, como por ejemplo, una funda de móvil.
<br/>9. Con unas flores y un poco de encaje, tus pantalones vaqueros o camisetas quedarán a la par de las nuevas tendencias.
<br/>10. Unos pantalones vaqueros pueden tener su segunda oportunidad en forma de mochila para el colegio o para excursiones, con todos los bolsillos que quieras.',
 '167562','42130','13530', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/ropa.jpg'), '2020-04-04', '¿Tienes ropa que ya no usas? No la tires.'),
--Publicaion 4
 ('beap', '5 útiles consejos para reutilizar botellas de plástico','1. Macetas para cultivar tomates
 Una perfecta solución para personas que quieren disfrutar de tomates de cosecha propia, pero no tienen un patio. Podemos cultivar nuestros propios alimentos incluso disponiendo de muy pocos metros utilizando botellas de plástico.
 <br/>2. Coche solar casero de juguete
 Una manualidad ideal para hacer con los más pequeños de la casa. Además la mayoría de los materiales que usaremos serán reciclados.
 <br/>3. Linterna casera
 La base del proyecto será una botella de plástico que, junto con palitos de helado, pegamento y el material eléctrico necesario, nos harán pasar un buen rato y poder fabricar nuestra propia linterna casera.
 <br/>4. Árbol de Navidad
 Con botellas PET de color verde, de las que hay muchas en el mercado, podemos hacer un árbol de navidad visualmente muy atractivo.
 <br/>5. Goteo solar con botellas de plástico
 Kondenskompressor es una técnica que produce agua destilada con radiación solar. Es un sistema muy simple y eficaz que produce un goteo solar mediante el cual se puede reducir el agua de riego 10 veces respecto a sistemas tradicionales.',
 '562','430','95', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/botella.jpg'), '2020-04-04', 'Da una 2º vida a tus botellas de plástico'),
--Publicacion 5 (nombreUsuario,	titulo,	texto, visualizaciones, valoraciones, hechos, foto, fechaCreacion, descripcion)
('beap',	'3 cosas (eco) que no sabías de tus bolígrafos',	'Voy a confesar una cosa: en mi casa hay un bote de lápices y la mayoría de ellos no escriben. ¡¿Que a ti también te pasa lo mismo?! Voy a suponer que sí, porque sería un alivio saber que no soy la única a la que se le olvida reciclar los bolígrafos.

Parece que nunca sabemos qué hacer con ellos y, por lo menos en mi caso, siempre se me olvida llevarlos al punto limpio, pero como vamos a ver hay varias cosas que igual no sabes sobre los bolis que tienes en casa.
1. El bolígrafo más ecológico es el que ya tienes.

Puede que el que tengas en casa sea de publicidad, muy feo y de plástico, pero será más ecológico y sobre todo más lógico si lo usas antes de comprarte otro.

Busca entre todos tus bolis y selecciona los que no tienen tinta y no se pueden recargar. Más adelante te explico qué vamos a hacer con ellos.
<br/>2. Los bolígrafos recargables son siempre una buena opción.

En vez de comprar el boli entero cada vez que se gasta es mejor que inviertas en un boli o pluma que se pueda recargar. Así cuando la tinta se termine solo tienes que comprar una «mina» más para seguir usándolo.
<br/>3. No van al contenedor amarillo, pero sí se pueden reciclar los bolígrafos', '2', '2', '0', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/bolis.jpg'), '2020-05-25', '¿Qué hago con los bolígrafos que ya no uso?'),
--Publicacion 6 (nombreUsuario,	titulo,	texto, visualizaciones, valoraciones, hechos, foto, fechaCreacion, descripcion)
('hecgon',	'3 ideas creativas para reciclar tus bolígrafos',
'Lo más importante es asegurarnos de que nuestro bolígrafo ya no da más de si. Otro de los fenómenos de la sociedad actual es la inmediatez y la falta de paciencia y sosiego. Lo queremos todo ya, y si no lo tenemos buscamos la solución más fácil. Esto no siempre tiene por qué ser así, cuando tu bolígrafo deje de escribir o notes que la tinta se ha secado, haz todo lo posible para solucionarlo. En este artículo ya te explicamos qué hacer para recuperar los bolígrafos que se hayan secado.

Si a pesar de todos los intentos tu bolígrafo ha llegado a su fin, apunta estas 3 ideas para reciclarlos y que no entren a formar parte de la basura que inunda el planeta:


  1.  Lapicero con bolígrafos. Tiene sentido, en vez de comprar un lapicero de plástico o de metal, difícil de reciclar, se puede construir uno con los bolígrafos que ya no utilicemos. Puedes aprovechar cajitas de madera antiguas o incluso latas de refresco. Aplicas una capa de cola transparente y se van colocando los bolis en vertical, uno al lado del otro. Se deja secar… ¡Y listo!
  <br/>2.  Bisutería. Los bolígrafos antiguos también pueden servir para crear piezas de bisutería. En este caso, para darle forma a las joyas usaremos las puntas de los bolígrafos.
  <br/>3.  Objetos decorativos. Los bolígrafos que ya no utilices puedes usarlos como infinidad de objetos de decoración y así también ahorrarás dinero. Puedes engancharle purpurina de colores con la ayuda de cola transparente, también pintarlos con rotuladores permanentes o forrarlos con papel vegetal. También con la ayuda de una mini sierra los puedes cortar en pedacitos pequeños y colocarlos dentro de un jarrón transparente con flores secas y otro tipo de adornos. Sin duda le darás un toque de color y muy diferente a tu hogar.
', '258', '114', '20', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/bolis2.jpg'), '2020-01-08', '3 ideas creativas para reciclar tus bolígrafos'),
--Publicacion 7 (nombreUsuario,	titulo,	texto, visualizaciones, valoraciones, hechos, foto, fechaCreacion, descripcion)
('beap',	'4 maneras creativas de reutilizar la cáscara de naranja',	'<b>1. Una vela aromática</b>
	<br/>¿Cómo hacerla?

    <br/>*Corta la parte superior de la naranja y extrae su pulpa sin romper la cáscara.
    <br/>*Luego rellena hasta la mitad con cera para velas y ponle una mecha.

<br/><b>2. Abrillantar el acero inoxidable</b>

	<br/>El ácido cítrico que se encuentra en estas cáscaras es un buen agente para abrillantar y desinfectar diversas superficies de acero inoxidable.

<br/>¿Cómo utilizarlo?

    <br/>*Corta la piel de naranja y frota la parte interior sobre los fregaderos, grifos y otros elementos de este material.

<br/><b>3. Limpiador multiusos</b>
<br/>Combinando las propiedades de este cítrico con los beneficios del vinagre podemos crear un limpiador multiusos para desinfectar la casa y quitar las manchas.

<br/>El producto tendrá un poderoso efecto antibacteriano y quitamanchas que nos servirá como alternativa a los químicos agresivos del mercado.
<br/>Ingredientes

  <br/>*  1 taza de vinagre blanco (250 ml)
  <br/>*  2 cáscaras de naranja

<br/>¿Cómo hacerlo?

  <br/>*  Vierte el vinagre blanco en un frasco y agrégale las cáscaras de naranja.
    <br/>*  Ponlo en un sitio oscuro durante una semana y empieza a utilizarlo.
    <br/>  Incorpora el líquido en un frasco con atomizador para que te sea más fácil aplicarlo.', '0', '0', '0', LOAD_FILE('/var/lib/mysql-files/imagenesPoblar/publicaciones/naranja.jpg'), '2020-05-25', 'No tires las cascára de naranaj, reutilizalas.');


--Guardados
INSERT INTO GUARDADO (id_publicacion, login)
values ('2','hecgon'),
('3','hecgon'),
('1','beap'),
('6','beap'),
('7','hecgon');

--Objetos_Utilizados
INSERT INTO OBJETO_UTILIZADO (id_publicacion, nombre)
values ('1','lata'),
('2','lata'),
('3','ropa textil'),
('4','botella'),
('6','bolígrafo');
